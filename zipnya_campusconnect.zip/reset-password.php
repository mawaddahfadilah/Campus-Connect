<?php
require_once 'includes/functions.php';

// Redirect if already logged in
if (is_logged_in()) {
    header("Location: feed.php");
    exit();
}

$token = sanitize($_GET['token'] ?? $_POST['token'] ?? '');
$error = '';
$user = null;

if (empty($token)) {
    $error = 'Token reset tidak ditemukan atau tidak valid.';
} else {
    try {
        // Find token and check expiry
        $stmt = $pdo->prepare("SELECT * FROM users WHERE reset_token = ? AND reset_token_expires > NOW()");
        $stmt->execute([$token]);
        $user = $stmt->fetch();

        if (!$user) {
            $error = 'Token reset kadaluwarsa atau tidak valid. Silakan ajukan ulang lupa password.';
        }
    } catch (PDOException $e) {
        $error = 'Terjadi kesalahan sistem: ' . $e->getMessage();
    }
}

// Handle Password Change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $user) {
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($password) || empty($confirm_password)) {
        $error = 'Semua field wajib diisi.';
    } elseif (!validate_password($password)) {
        $error = 'Password minimal harus 8 karakter.';
    } elseif ($password !== $confirm_password) {
        $error = 'Konfirmasi password tidak cocok.';
    } else {
        try {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            
            // Update password & clear token
            $update_stmt = $pdo->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?");
            $update_stmt->execute([$hashed_password, $user['id']]);
            
            log_activity('Password Reset Success', "User {$user['name']} reset password successfully.");
            
            set_flash_message('success', 'Password Anda berhasil diperbarui! Silakan login.');
            header("Location: login.php");
            exit();
        } catch (PDOException $e) {
            $error = 'Gagal memperbarui password: ' . $e->getMessage();
        }
    }
}

require_once 'includes/header.php';
?>

<div class="app-container">
    <div class="auth-container animate-fade-in">
        <div class="auth-header">
            <h2 class="auth-title">Reset Password</h2>
            <p class="auth-subtitle">Masukkan password baru Anda di bawah ini</p>
        </div>

        <?php if (!empty($error) && !$user): ?>
            <div class="flash-banner flash-error">
                <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
            </div>
            <div style="text-align: center; margin-top: 20px;">
                <a href="login.php" class="btn btn-secondary">Kembali ke Login</a>
            </div>
        <?php else: ?>
            
            <?php if (!empty($error)): ?>
                <div class="flash-banner flash-error">
                    <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <div class="card">
                <form action="reset-password.php" method="POST" class="validate-form register-form">
                    <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                    
                    <div class="form-group">
                        <label for="password" class="form-label">Password Baru</label>
                        <input type="password" name="password" id="password" class="form-input" placeholder="Minimal 8 karakter" required>
                    </div>

                    <div class="form-group">
                        <label for="confirm_password" class="form-label">Konfirmasi Password Baru</label>
                        <input type="password" name="confirm_password" id="confirm_password" class="form-input" placeholder="Ulangi password baru Anda" required>
                    </div>

                    <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;">Perbarui Password</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
