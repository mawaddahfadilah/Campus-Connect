<?php
/**
 * CampusConnect Database Migration Utility
 * Run this script once in your browser to create the user_portfolio table.
 */
require_once 'includes/config.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS `user_portfolio` (
      `id` INT AUTO_INCREMENT PRIMARY KEY,
      `user_id` INT NOT NULL,
      `file_name` VARCHAR(255) NOT NULL,
      `caption` VARCHAR(255) NULL,
      `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
    
    $pdo->exec($sql);
    echo "<h1>Migration Success</h1>";
    echo "<p>Table <code>user_portfolio</code> has been created successfully in database.</p>";
    echo "<a href='index.php'>Go to Home</a>";
} catch (PDOException $e) {
    echo "<h1>Migration Failed</h1>";
    echo "<p>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
