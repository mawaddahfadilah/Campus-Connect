<?php
require_once 'includes/header.php';

$stat_users = $stat_projects = $stat_active = $stat_collaborations = 0;
try {
    $stat_users          = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $stat_projects       = $pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
    $stat_active         = $pdo->query("SELECT COUNT(*) FROM projects WHERE status = 'Open'")->fetchColumn();
    $stat_collaborations = $pdo->query("SELECT COUNT(*) FROM project_applications WHERE status = 'approved'")->fetchColumn();
} catch (Exception $e) {
    $stat_users = 5; $stat_projects = 3; $stat_active = 3;
}

$recent_projects = [];
try {
    $stmt = $pdo->query("SELECT p.*, u.name as owner_name, u.foto as owner_foto
                         FROM projects p JOIN users u ON p.owner_id = u.id
                         WHERE p.status = 'Open' ORDER BY p.id DESC LIMIT 3");
    $recent_projects = $stmt->fetchAll();
} catch (Exception $e) {}
?>

<!-- ===== HERO ===== -->
<section class="lp-hero">
    <div class="lp-hero-inner">
        <div class="lp-hero-text animate-fade-in">
            <div class="lp-eyebrow">Platform Kolaborasi Kampus</div>
            <h1 class="lp-headline">Temukan Tim,<br>Wujudkan Project<br>Kampus Terbaikmu</h1>
            <p class="lp-sub">
                CampusConnect menyatukan mahasiswa berbakat di seluruh kampus — dari PKM, Startup,
                Lomba, hingga Volunteer. Satu platform untuk semua kolaborasi akademik dan non-akademikmu.
            </p>
            <div class="lp-cta-row">
                <?php if ($is_logged): ?>
                    <a href="feed.php" class="btn btn-primary btn-lg">
                        <i class="fa-solid fa-compass"></i> Jelajahi Project
                    </a>
                    <a href="project-create.php" class="btn btn-secondary btn-lg">
                        <i class="fa-solid fa-plus"></i> Buat Project
                    </a>
                <?php else: ?>
                    <a href="register.php" class="btn btn-primary btn-lg">
                        <i class="fa-solid fa-user-plus"></i> Mulai Sekarang
                    </a>
                    <a href="feed.php" class="btn btn-secondary btn-lg">
                        Lihat Project <i class="fa-solid fa-arrow-right"></i>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="lp-hero-visual animate-fade-in-delay">
            <div class="lp-stat-stack">
                <div class="lp-stat-pill">
                    <div class="lp-stat-pill-num"><?php echo $stat_users; ?>+</div>
                    <div class="lp-stat-pill-lbl">Mahasiswa</div>
                </div>
                <div class="lp-stat-pill accent-green">
                    <div class="lp-stat-pill-num"><?php echo $stat_active; ?></div>
                    <div class="lp-stat-pill-lbl">Project Aktif</div>
                </div>
                <div class="lp-stat-pill accent-amber">
                    <div class="lp-stat-pill-num"><?php echo $stat_collaborations; ?>+</div>
                    <div class="lp-stat-pill-lbl">Kolaborasi</div>
                </div>
                <div class="lp-stat-pill accent-purple">
                    <div class="lp-stat-pill-num"><?php echo $stat_projects; ?></div>
                    <div class="lp-stat-pill-lbl">Total Project</div>
                </div>
            </div>
            <!-- Category badges visual -->
            <div class="lp-badge-cloud">
                <span class="badge badge-pkm">PKM</span>
                <span class="badge badge-startup">Startup</span>
                <span class="badge badge-lomba">Lomba</span>
                <span class="badge badge-volunteer">Volunteer</span>
                <span class="badge badge-p2mw">P2MW</span>
                <span class="badge badge-organisasi">Organisasi</span>
                <span class="badge badge-event">Event Kampus</span>
            </div>
        </div>
    </div>
</section>

<!-- ===== HOW IT WORKS ===== -->
<section class="lp-section lp-how">
    <div class="app-container">
        <div class="lp-section-header">
            <h2>Cara Kerjanya</h2>
            <p>Tiga langkah mudah untuk mulai berkolaborasi</p>
        </div>
        <div class="lp-steps">
            <div class="lp-step">
                <div class="lp-step-num">01</div>
                <div class="lp-step-icon"><i class="fa-solid fa-user-check"></i></div>
                <h3>Lengkapi Profil</h3>
                <p>Daftarkan diri dan isi profil dengan keahlian, minat, dan riwayat pengalaman organisasimu.</p>
            </div>
            <div class="lp-step-divider"><i class="fa-solid fa-chevron-right"></i></div>
            <div class="lp-step">
                <div class="lp-step-num">02</div>
                <div class="lp-step-icon"><i class="fa-solid fa-magnifying-glass"></i></div>
                <h3>Temukan Project</h3>
                <p>Telusuri ratusan project sesuai kategori atau skill yang kamu miliki, lalu lamar langsung.</p>
            </div>
            <div class="lp-step-divider"><i class="fa-solid fa-chevron-right"></i></div>
            <div class="lp-step">
                <div class="lp-step-num">03</div>
                <div class="lp-step-icon"><i class="fa-solid fa-people-group"></i></div>
                <h3>Mulai Berkarya</h3>
                <p>Setelah diterima, bergabunglah dengan tim dan mulai wujudkan project impianmu bersama.</p>
            </div>
        </div>
    </div>
</section>

<!-- ===== RECENT PROJECTS ===== -->
<section class="lp-section lp-recent">
    <div class="app-container">
        <div class="lp-section-header">
            <h2>Project Terbaru</h2>
            <p>Project kolaborasi yang baru saja dibuka dan mencari anggota tim</p>
        </div>

        <?php if (empty($recent_projects)): ?>
            <div class="empty-state">
                <div class="empty-state-icon"><i class="fa-solid fa-folder-open"></i></div>
                <div class="empty-state-title">Belum ada project aktif</div>
                <p class="empty-state-desc">Jadilah yang pertama memposting project kolaborasi!</p>
                <a href="project-create.php" class="btn btn-primary">Buat Project</a>
            </div>
        <?php else: ?>
            <div class="project-grid">
                <?php foreach ($recent_projects as $project):
                    $skills = [];
                    try {
                        $s_stmt = $pdo->prepare("SELECT skill_name FROM project_skills WHERE project_id = ?");
                        $s_stmt->execute([$project['id']]);
                        $skills = $s_stmt->fetchAll(PDO::FETCH_COLUMN);
                    } catch (Exception $e) {}
                    $cat_lower  = strtolower($project['category']);
                    $badge_cls  = 'badge-lainnya';
                    $cat_map    = ['pkm'=>'pkm','p2mw'=>'p2mw','lomba'=>'lomba','startup'=>'startup','volunteer'=>'volunteer','organisasi'=>'organisasi','event kampus'=>'event'];
                    if (isset($cat_map[$cat_lower])) $badge_cls = 'badge-' . $cat_map[$cat_lower];

                    $p_parts = explode(' ', $project['owner_name']);
                    $p_init = strtoupper(substr($p_parts[0],0,1).(isset($p_parts[1])?substr($p_parts[1],0,1):''));
                ?>
                <a href="project-detail.php?id=<?php echo $project['id']; ?>" class="project-card">
                    <div class="project-card-top">
                        <div class="project-card-badges">
                            <span class="badge <?php echo $badge_cls; ?>"><?php echo htmlspecialchars($project['category']); ?></span>
                            <span class="badge badge-open">Open</span>
                        </div>
                    </div>
                    <div class="project-title"><?php echo htmlspecialchars($project['title']); ?></div>
                    <div class="project-desc"><?php echo htmlspecialchars($project['description']); ?></div>

                    <?php if (!empty($skills)): ?>
                    <div class="skill-tags-list">
                        <?php foreach (array_slice($skills, 0, 4) as $sk): ?>
                            <span class="skill-tag"><?php echo htmlspecialchars($sk); ?></span>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>

                    <div class="project-card-footer">
                        <div class="owner-info">
                            <?php if (!empty($project['owner_foto']) && file_exists('uploads/' . $project['owner_foto'])): ?>
                                <img src="uploads/<?php echo htmlspecialchars($project['owner_foto']); ?>" alt="" class="owner-avatar">
                            <?php else: ?>
                                <div class="owner-avatar-placeholder"><?php echo $p_init; ?></div>
                            <?php endif; ?>
                            <span class="owner-name"><?php echo htmlspecialchars($project['owner_name']); ?></span>
                        </div>
                        <span class="link-arrow">Lihat <i class="fa-solid fa-arrow-right"></i></span>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>

            <div style="text-align:center; margin-top: 36px;">
                <a href="feed.php" class="btn btn-secondary btn-lg">
                    Lihat Semua Project <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- ===== CTA BAND ===== -->
<?php if (!$is_logged): ?>
<section class="lp-cta-band">
    <div class="lp-cta-band-inner">
        <h2>Siap untuk berkolaborasi?</h2>
        <p>Bergabunglah dengan ratusan mahasiswa yang sudah aktif membangun project bersama.</p>
        <a href="register.php" class="btn btn-primary btn-lg">
            <i class="fa-solid fa-user-plus"></i> Daftar Gratis Sekarang
        </a>
    </div>
</section>
<?php endif; ?>

<style>
/* ===== LANDING PAGE SPECIFIC STYLES ===== */
.lp-hero {
    background: var(--color-bg);
    border-bottom: 1px solid var(--color-border);
    padding: 80px 24px;
}
.lp-hero-inner {
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 1fr 420px;
    gap: 64px;
    align-items: center;
}
@media (max-width: 900px) {
    .lp-hero-inner { grid-template-columns: 1fr; gap: 40px; }
}

.lp-eyebrow {
    font-size: 0.8125rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: var(--color-primary);
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.lp-eyebrow::before {
    content: '';
    display: inline-block;
    width: 24px;
    height: 2px;
    background: var(--color-primary);
    border-radius: 2px;
}

.lp-headline {
    font-family: var(--font-heading);
    font-size: clamp(2rem, 4vw, 3rem);
    font-weight: 800;
    color: var(--color-text-primary);
    line-height: 1.15;
    margin-bottom: 20px;
    letter-spacing: -0.03em;
}

.lp-sub {
    font-size: 1.0625rem;
    color: var(--color-text-secondary);
    line-height: 1.7;
    max-width: 520px;
    margin-bottom: 32px;
}

.lp-cta-row {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
}

/* Right visual */
.lp-hero-visual {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.lp-stat-stack {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
}

.lp-stat-pill {
    background: var(--color-bg);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    padding: 20px;
    box-shadow: var(--shadow-sm);
    text-align: center;
    transition: box-shadow 0.2s ease;
}
.lp-stat-pill:hover { box-shadow: var(--shadow-md); }

.lp-stat-pill.accent-green { border-top: 3px solid var(--color-green); }
.lp-stat-pill.accent-amber { border-top: 3px solid var(--color-amber); }
.lp-stat-pill.accent-purple { border-top: 3px solid var(--color-purple); }
.lp-stat-pill:not([class*="accent"]) { border-top: 3px solid var(--color-primary); }

.lp-stat-pill-num {
    font-family: var(--font-heading);
    font-size: 2rem;
    font-weight: 800;
    color: var(--color-text-primary);
    line-height: 1.1;
    margin-bottom: 4px;
}

.lp-stat-pill-lbl {
    font-size: 0.8rem;
    color: var(--color-text-muted);
    font-weight: 500;
}

.lp-badge-cloud {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    justify-content: center;
}

/* Sections */
.lp-section { padding: 72px 0; }
.lp-section.lp-recent { background: var(--color-surface); }

.lp-section-header {
    text-align: center;
    margin-bottom: 48px;
}
.lp-section-header h2 {
    font-size: 1.875rem;
    font-weight: 700;
    margin-bottom: 8px;
}
.lp-section-header p {
    font-size: 1rem;
    color: var(--color-text-secondary);
}

/* Steps */
.lp-steps {
    display: flex;
    align-items: flex-start;
    justify-content: center;
    gap: 0;
    flex-wrap: wrap;
}

.lp-step {
    flex: 1;
    min-width: 200px;
    max-width: 280px;
    text-align: center;
    padding: 24px 16px;
}

.lp-step-num {
    font-family: var(--font-heading);
    font-size: 3rem;
    font-weight: 800;
    color: #E5E7EB;
    line-height: 1;
    margin-bottom: 12px;
}

.lp-step-icon {
    width: 52px;
    height: 52px;
    border-radius: var(--radius-md);
    background: var(--color-primary-light);
    color: var(--color-primary);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    margin: 0 auto 14px;
}

.lp-step h3 {
    font-size: 1.0625rem;
    font-weight: 700;
    margin-bottom: 8px;
}

.lp-step p {
    font-size: 0.875rem;
    color: var(--color-text-secondary);
    line-height: 1.6;
}

.lp-step-divider {
    color: #D1D5DB;
    font-size: 1.25rem;
    padding-top: 80px;
    flex-shrink: 0;
}

@media (max-width: 640px) {
    .lp-step-divider { display: none; }
    .lp-steps { flex-direction: column; align-items: center; }
}

/* CTA Band */
.lp-cta-band {
    background: var(--color-primary);
    padding: 72px 24px;
}
.lp-cta-band-inner {
    max-width: 600px;
    margin: 0 auto;
    text-align: center;
}
.lp-cta-band h2 {
    font-family: var(--font-heading);
    font-size: 2rem;
    font-weight: 700;
    color: #fff;
    margin-bottom: 12px;
}
.lp-cta-band p {
    color: rgba(255,255,255,0.8);
    font-size: 1.0625rem;
    margin-bottom: 28px;
    line-height: 1.6;
}
.lp-cta-band .btn-primary {
    background: #fff;
    color: var(--color-primary);
}
.lp-cta-band .btn-primary:hover {
    background: #F0F4FF;
}

/* Mobile tweaks for Landing Page */
@media (max-width: 768px) {
    .lp-hero {
        padding: 48px 16px;
    }
    .lp-headline {
        font-size: 1.875rem;
    }
    .lp-sub {
        font-size: 0.9375rem;
    }
    .lp-cta-row {
        flex-direction: column;
        align-items: stretch;
    }
    .lp-cta-row .btn {
        width: 100%;
        justify-content: center;
    }
    .lp-section {
        padding: 48px 0;
    }
    .lp-cta-band {
        padding: 48px 16px;
    }
    .lp-cta-band h2 {
        font-size: 1.5rem;
    }
    .lp-section-header {
        margin-bottom: 32px;
    }
    .lp-section-header h2 {
        font-size: 1.5rem;
    }
}

@media (max-width: 480px) {
    .lp-stat-pill-num { font-size: 1.5rem; }
    .lp-stat-pill { padding: 14px 10px; }
}
</style>

<?php require_once 'includes/footer.php'; ?>
