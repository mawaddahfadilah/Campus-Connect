<?php
require_once 'includes/functions.php';
require_login();
header("Location: settings.php");
exit();
?>
