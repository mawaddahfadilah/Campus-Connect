<?php
$page_title = "Admin Dashboard - CampusConnect";
$meta_description = "Administrative dashboard for CampusConnect, showing user statistics, recent activity, and system logs.";
require_once 'includes/functions.php';
require_admin();

// Statistics
$stat_users = $stat_projects = $stat_active = $stat_applications = $stat_collabs = $stat_pending = $stat_rejected = 0;
try {
    $stat_users = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn();
    $stat_projects = $pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
    $stat_active = $pdo->query("SELECT COUNT(*) FROM projects WHERE status = 'Open'")->fetchColumn();
    $stat_applications = $pdo->query("SELECT COUNT(*) FROM project_applications")->fetchColumn();
    $stat_collabs = $pdo->query("SELECT COUNT(*) FROM project_applications WHERE status = 'approved'")->fetchColumn();
    $stat_pending = $pdo->query("SELECT COUNT(*) FROM project_applications WHERE status = 'pending'")->fetchColumn();
    $stat_rejected = $pdo->query("SELECT COUNT(*) FROM project_applications WHERE status = 'rejected'")->fetchColumn();
} catch (PDOException $e) {
    set_flash_message('error', 'Gagal memuat statistik admin.');
}

// Percentages
$open_rate = $stat_projects > 0 ? round(($stat_active / $stat_projects) * 100) : 0;
$closed_rate = $stat_projects > 0 ? (100 - $open_rate) : 0;
$approved_rate = $stat_applications > 0 ? round(($stat_collabs / $stat_applications) * 100) : 0;
$pending_rate = $stat_applications > 0 ? round(($stat_pending / $stat_applications) * 100) : 0;
$rejected_rate = $stat_applications > 0 ? round(($stat_rejected / $stat_applications) * 100) : 0;

// Recent users
try {
    $recent_users = $pdo->query("SELECT * FROM users WHERE role = 'user' ORDER BY id DESC LIMIT 5")->fetchAll();
} catch (PDOException $e) {
    $recent_users = [];
}

// Recent activity logs
try {
    $activity_logs = $pdo->query("SELECT * FROM activity_logs ORDER BY id DESC LIMIT 10")->fetchAll();
} catch (PDOException $e) {
    $activity_logs = [];
}

require_once 'includes/header.php';
?>
<div class="app-container">
    <header class="dashboard-header">
        <h2>Dashboard Administrasi</h2>
        <p>Pantau perkembangan platform, registrasi mahasiswa, dan status kolaborasi project.</p>
    </header>
    <section class="admin-grid">
        <div class="card stat-card">
            <div class="stat-num"><?= $stat_users; ?></div>
            <div class="stat-lbl">Mahasiswa Terdaftar</div>
        </div>
        <div class="card stat-card">
            <div class="stat-num stat-num--secondary"><?= $stat_projects; ?></div>
            <div class="stat-lbl">Total Project</div>
        </div>
        <div class="card stat-card">
            <div class="stat-num stat-num--accent"><?= $stat_active; ?></div>
            <div class="stat-lbl">Project Aktif (Open)</div>
        </div>
        <div class="card stat-card">
            <div class="stat-num stat-num--warning"><?= $stat_applications; ?></div>
            <div class="stat-lbl">Pendaftaran Masuk</div>
        </div>
        <div class="card stat-card">
            <div class="stat-num stat-num--primary"><?= $stat_collabs; ?></div>
            <div class="stat-lbl">Kolaborasi Disetujui</div>
        </div>
    </section>
    <section class="admin-charts">
        <div class="chart-card">
            <h3 class="chart-title"><i class="fa-solid fa-chart-pie"></i> Rasio Status Project (Total: <?= $stat_projects; ?>)</h3>
            <div class="bar-chart">
                <div class="chart-bar">
                    <span class="label">Open / Aktif</span>
                    <div class="bar" style="width: <?= $open_rate; ?>%; background: var(--color-accent);"></div>
                    <span class="value"><?= $open_rate; ?>%</span>
                </div>
                <div class="chart-bar">
                    <span class="label">Closed / Tutup</span>
                    <div class="bar" style="width: <?= $closed_rate; ?>%; background: var(--color-danger);"></div>
                    <span class="value"><?= $closed_rate; ?>%</span>
                </div>
            </div>
        </div>
        <div class="chart-card">
            <h3 class="chart-title"><i class="fa-solid fa-chart-bar"></i> Status Pendaftaran Masuk (Total: <?= $stat_applications; ?>)</h3>
            <div class="bar-chart">
                <div class="chart-bar">
                    <span class="label">Disetujui</span>
                    <div class="bar" style="width: <?= $approved_rate; ?>%; background: var(--color-primary);"></div>
                    <span class="value"><?= $approved_rate; ?>%</span>
                </div>
                <div class="chart-bar">
                    <span class="label">Pending</span>
                    <div class="bar" style="width: <?= $pending_rate; ?>%; background: var(--color-warning);"></div>
                    <span class="value"><?= $pending_rate; ?>%</span>
                </div>
                <div class="chart-bar">
                    <span class="label">Ditolak</span>
                    <div class="bar" style="width: <?= $rejected_rate; ?>%; background: var(--color-danger);"></div>
                    <span class="value"><?= $rejected_rate; ?>%</span>
                </div>
            </div>
        </div>
    </section>
    <section class="admin-split">
        <div class="column recent-users">
            <h3 class="section-title">Mahasiswa Baru Terdaftar</h3>
            <table class="admin-table">
                <thead>
                    <tr><th>Nama</th><th>Email</th><th>Tanggal Daftar</th></tr>
                </thead>
                <tbody>
                <?php if (empty($recent_users)): ?>
                    <tr><td colspan="3" class="text-center muted">Belum ada mahasiswa baru.</td></tr>
                <?php else: foreach ($recent_users as $ru): ?>
                    <tr>
                        <td><a href="profile.php?id=<?= $ru['id']; ?>" class="link-primary"><?= htmlspecialchars($ru['name']); ?></a></td>
                        <td><?= htmlspecialchars($ru['email']); ?></td>
                        <td><?= date('d M Y', strtotime($ru['created_at'])); ?></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
            <div class="text-right"><a href="admin-users.php" class="btn btn-secondary btn-sm">Kelola Semua Mahasiswa <i class="fa-solid fa-arrow-right"></i></a></div>
        </div>
        <div class="column activity-logs">
            <h3 class="section-title">Log Aktivitas Sistem</h3>
            <div class="log-list">
                <?php if (empty($activity_logs)): ?>
                    <p class="muted">Belum ada log aktivitas.</p>
                <?php else: foreach ($activity_logs as $log): ?>
                    <div class="log-item">
                        <strong class="log-action text-secondary"><?= htmlspecialchars($log['action']); ?></strong> — <span class="log-detail muted"><?= htmlspecialchars($log['details']); ?></span>
                        <span class="log-time muted"><?= date('H:i', strtotime($log['created_at'])); ?></span>
                    </div>
                <?php endforeach; endif; ?>
            </div>
        </div>
    </section>
</div>
<?php require_once 'includes/footer.php'; ?>
