<?php
require_once 'includes/functions.php';

if (is_logged_in()) {
    log_activity('User Logged Out', "User {$_SESSION['name']} ({$_SESSION['email']}) logged out.");
    
    // Unset all session variables
    $_SESSION = array();

    // Destroy the session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // Destroy session
    session_destroy();
}

// Set success message and redirect
session_start();
set_flash_message('info', 'Anda telah berhasil keluar dari akun.');
header("Location: login.php");
exit();
?>
