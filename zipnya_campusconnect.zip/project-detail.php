<?php
require_once 'includes/functions.php';
require_login();

$project_id      = isset($_GET['id']) ? intval($_GET['id']) : 0;
$user_id         = $_SESSION['user_id'];
$project         = null;
$skills          = [];
$application     = null;
$approved_members = [];

try {
    $stmt = $pdo->prepare("SELECT p.*, u.name as owner_name, u.email as owner_email,
                           u.foto as owner_foto, u.jurusan as owner_jurusan, u.angkatan as owner_angkatan
                           FROM projects p JOIN users u ON p.owner_id = u.id WHERE p.id = ?");
    $stmt->execute([$project_id]);
    $project = $stmt->fetch();

    if (!$project) {
        set_flash_message('error', 'Project tidak ditemukan.');
        header("Location: feed.php"); exit();
    }

    $s_stmt = $pdo->prepare("SELECT skill_name FROM project_skills WHERE project_id = ?");
    $s_stmt->execute([$project_id]);
    $skills = $s_stmt->fetchAll(PDO::FETCH_COLUMN);

    $app_stmt = $pdo->prepare("SELECT * FROM project_applications WHERE project_id = ? AND applicant_id = ?");
    $app_stmt->execute([$project_id, $user_id]);
    $application = $app_stmt->fetch();

    $mem_stmt = $pdo->prepare("SELECT u.id, u.name, u.foto, u.jurusan, u.angkatan
                               FROM users u JOIN project_applications pa ON u.id = pa.applicant_id
                               WHERE pa.project_id = ? AND pa.status = 'approved'");
    $mem_stmt->execute([$project_id]);
    $approved_members = $mem_stmt->fetchAll();

    $is_bookmarked = false;
    if ($_SESSION['role'] !== 'admin') {
        $bm = $pdo->prepare("SELECT 1 FROM project_bookmarks WHERE user_id = ? AND project_id = ?");
        $bm->execute([$user_id, $project_id]);
        $is_bookmarked = (bool)$bm->fetchColumn();
    }

} catch (PDOException $e) {
    set_flash_message('error', 'Terjadi kesalahan database.');
    header("Location: feed.php"); exit();
}

$is_owner = ($project['owner_id'] === $user_id);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$is_owner && !$application) {
    $motivation = sanitize($_POST['motivation'] ?? '');
    if ($project['status'] === 'Closed') {
        $error = 'Pendaftaran project ini sudah ditutup.';
    } elseif (empty($motivation)) {
        $error = 'Silakan tulis motivasi bergabung Anda.';
    } else {
        try {
            if (count($approved_members) >= $project['slots']) {
                $error = 'Maaf, slot project sudah penuh.';
            } else {
                $ins = $pdo->prepare("INSERT INTO project_applications (project_id, applicant_id, motivation, status) VALUES (?, ?, ?, 'pending')");
                $ins->execute([$project_id, $user_id, $motivation]);
                $notif = "<strong>" . htmlspecialchars($_SESSION['name']) . "</strong> mengajukan diri di project <strong>" . htmlspecialchars($project['title']) . "</strong>.";
                add_notification($project['owner_id'], $notif);
                log_activity('Join Requested', "User {$user_id} applied to project ID {$project_id}.");
                set_flash_message('success', 'Lamaran berhasil dikirim! Tunggu konfirmasi dari Project Owner.');
                header("Location: project-detail.php?id=" . $project_id); exit();
            }
        } catch (PDOException $e) {
            $error = 'Terjadi kesalahan sistem.';
        }
    }
}

// Badge helper
$cat_lower = strtolower($project['category']);
$cat_map   = ['pkm'=>'pkm','p2mw'=>'p2mw','lomba'=>'lomba','startup'=>'startup','volunteer'=>'volunteer','organisasi'=>'organisasi','event kampus'=>'event'];
$badge_cls = 'badge-lainnya';
if (isset($cat_map[$cat_lower])) $badge_cls = 'badge-' . $cat_map[$cat_lower];
$status_badge = ($project['status'] === 'Open') ? 'badge-open' : 'badge-closed';

$o_parts = explode(' ', $project['owner_name']);
$o_init  = strtoupper(substr($o_parts[0],0,1).(isset($o_parts[1])?substr($o_parts[1],0,1):''));

require_once 'includes/header.php';
?>

<div class="app-container">

    <!-- Breadcrumb -->
    <div class="detail-breadcrumb animate-fade-in">
        <a href="feed.php" class="detail-back">
            <i class="fa-solid fa-chevron-left"></i> Kembali ke Feed
        </a>
        <div class="detail-breadcrumb-actions">
            <?php if ($_SESSION['role'] !== 'admin' && !$is_owner): ?>
                <a href="project-bookmark.php?id=<?php echo $project['id']; ?>&redirect=detail"
                   class="btn btn-neutral btn-sm <?php echo $is_bookmarked ? 'bookmarked' : ''; ?>">
                    <i class="<?php echo $is_bookmarked ? 'fa-solid' : 'fa-regular'; ?> fa-bookmark"></i>
                    <?php echo $is_bookmarked ? 'Disimpan' : 'Simpan'; ?>
                </a>
            <?php endif; ?>
            <?php if ($is_owner): ?>
                <a href="project-edit.php?id=<?php echo $project['id']; ?>" class="btn btn-neutral btn-sm">
                    <i class="fa-regular fa-pen-to-square"></i> Edit
                </a>
                <a href="project-manage.php?id=<?php echo $project['id']; ?>" class="btn btn-primary btn-sm">
                    <i class="fa-solid fa-people-roof"></i> Kelola Tim
                </a>
            <?php endif; ?>
        </div>
    </div>

    <?php if (isset($error)): ?>
        <div class="flash-banner flash-error animate-fade-in">
            <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <!-- 2-Column Layout -->
    <div class="detail-layout animate-fade-in">

        <!-- ===== MAIN COLUMN ===== -->
        <div class="detail-main">

            <!-- Project Header -->
            <div class="detail-header">
                <div class="detail-meta-row">
                    <span class="badge <?php echo $badge_cls; ?>"><?php echo htmlspecialchars($project['category']); ?></span>
                    <span class="badge <?php echo $status_badge; ?>"><?php echo htmlspecialchars($project['status']); ?></span>
                </div>
                <h1 class="detail-title"><?php echo htmlspecialchars($project['title']); ?></h1>
                <div class="detail-byline">
                    <?php if (!empty($project['owner_foto']) && file_exists('uploads/' . $project['owner_foto'])): ?>
                        <img src="uploads/<?php echo htmlspecialchars($project['owner_foto']); ?>" alt="" class="owner-avatar" style="width:22px;height:22px;">
                    <?php else: ?>
                        <div class="owner-avatar-placeholder" style="width:22px;height:22px;font-size:0.55rem;"><?php echo $o_init; ?></div>
                    <?php endif; ?>
                    Dipublikasikan oleh <strong><?php echo htmlspecialchars($project['owner_name']); ?></strong>
                    &nbsp;·&nbsp; <?php echo date('d M Y', strtotime($project['created_at'])); ?>
                </div>
            </div>

            <!-- Description -->
            <div>
                <div class="detail-section-title">Deskripsi Project</div>
                <div class="detail-description"><?php echo htmlspecialchars($project['description']); ?></div>
            </div>

            <!-- Required Skills -->
            <?php if (!empty($skills)): ?>
            <div>
                <div class="detail-section-title">Keahlian yang Dibutuhkan</div>
                <div class="skill-tags-list">
                    <?php foreach ($skills as $s): ?>
                        <span class="skill-tag"><?php echo htmlspecialchars($s); ?></span>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Apply / Status Section -->
            <?php if (!$is_owner && $_SESSION['role'] !== 'admin'): ?>
            <div class="apply-box">
                <?php if ($application): ?>
                    <?php
                    $status_map = [
                        'pending'  => ['badge'=>'badge-pending', 'icon'=>'fa-clock',        'label'=>'Menunggu Review',  'msg'=>'Lamaran Anda telah terkirim. Project Owner sedang mereview profil Anda.'],
                        'approved' => ['badge'=>'badge-open',    'icon'=>'fa-circle-check',  'label'=>'Diterima',         'msg'=>'Selamat! Anda diterima sebagai anggota tim kolaborasi ini.'],
                        'rejected' => ['badge'=>'badge-closed',  'icon'=>'fa-circle-xmark',  'label'=>'Ditolak',          'msg'=>'Maaf, lamaran Anda belum disetujui untuk project ini.'],
                    ];
                    $s_info = $status_map[$application['status']] ?? $status_map['pending'];
                    ?>
                    <div class="apply-box-status">
                        <span class="badge <?php echo $s_info['badge']; ?>">
                            <i class="fa-regular <?php echo $s_info['icon']; ?>"></i>&nbsp; <?php echo $s_info['label']; ?>
                        </span>
                        <span><?php echo $s_info['msg']; ?></span>
                    </div>
                    <?php if ($application['status'] === 'approved' && !empty($project['contact_link'])): ?>
                        <div class="simulation-banner" style="margin-top:14px;">
                            <h4><i class="fa-solid fa-comments"></i> Hubungi Tim Kolaborasi</h4>
                            <p style="font-size:0.875rem; color:var(--color-text-secondary); margin-bottom:12px;">
                                Gunakan link berikut untuk bergabung ke grup komunikasi dan koordinasi project:
                            </p>
                            <a href="<?php echo htmlspecialchars($project['contact_link']); ?>" target="_blank" class="btn btn-primary btn-sm">
                                <i class="fa-solid fa-arrow-up-right-from-square"></i> Buka Tautan Komunikasi
                            </a>
                        </div>
                    <?php endif; ?>

                <?php elseif ($project['status'] === 'Closed'): ?>
                    <div class="flash-banner flash-error" style="margin-bottom:0;">
                        <i class="fa-solid fa-lock"></i> Pendaftaran project ini sudah ditutup.
                    </div>
                <?php elseif (count($approved_members) >= $project['slots']): ?>
                    <div class="flash-banner flash-warning" style="margin-bottom:0;">
                        <i class="fa-solid fa-users-slash"></i> Slot anggota sudah penuh.
                    </div>
                <?php else: ?>
                    <div class="detail-section-title" style="margin-bottom:16px;">Lamar untuk Bergabung</div>
                    <form action="project-detail.php?id=<?php echo $project['id']; ?>" method="POST">
                        <div class="form-group">
                            <label for="motivation" class="form-label">Motivasi & Keahlian Relevan</label>
                            <textarea name="motivation" id="motivation" class="form-input" rows="4"
                                      placeholder="Jelaskan mengapa Anda tertarik dan keahlian apa yang bisa Anda kontribusikan..."
                                      required style="resize:vertical;"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fa-solid fa-paper-plane"></i> Kirim Lamaran
                        </button>
                    </form>
                <?php endif; ?>
            </div>
            <?php endif; ?>

        </div>

        <!-- ===== SIDEBAR ===== -->
        <div class="detail-sidebar">

            <!-- Specs Card -->
            <div class="spec-card">
                <div class="spec-card-header">Detail Project</div>
                <ul class="spec-list">
                    <li class="spec-item">
                        <span class="spec-label"><i class="fa-solid fa-tag"></i> Kategori</span>
                        <span class="spec-value"><?php echo htmlspecialchars($project['category']); ?></span>
                    </li>
                    <li class="spec-item">
                        <span class="spec-label"><i class="fa-solid fa-circle-dot"></i> Status</span>
                        <span class="spec-value"><span class="badge <?php echo $status_badge; ?>"><?php echo htmlspecialchars($project['status']); ?></span></span>
                    </li>
                    <li class="spec-item">
                        <span class="spec-label"><i class="fa-solid fa-users"></i> Slot</span>
                        <span class="spec-value"><?php echo count($approved_members); ?> / <?php echo htmlspecialchars($project['slots']); ?></span>
                    </li>
                    <?php if (!empty($project['deadline'])): ?>
                    <li class="spec-item">
                        <span class="spec-label"><i class="fa-regular fa-calendar"></i> Deadline</span>
                        <span class="spec-value"><?php echo date('d M Y', strtotime($project['deadline'])); ?></span>
                    </li>
                    <?php endif; ?>
                    <li class="spec-item">
                        <span class="spec-label"><i class="fa-regular fa-clock"></i> Dibuat</span>
                        <span class="spec-value"><?php echo date('d M Y', strtotime($project['created_at'])); ?></span>
                    </li>
                </ul>
            </div>

            <!-- Owner Card -->
            <div class="spec-card owner-card">
                <div class="spec-card-header">Project Owner</div>
                <div style="padding:16px;">
                    <div class="owner-card-profile" onclick="window.location.href='profile.php?id=<?php echo $project['owner_id']; ?>'">
                        <?php if (!empty($project['owner_foto']) && file_exists('uploads/' . $project['owner_foto'])): ?>
                            <img src="uploads/<?php echo htmlspecialchars($project['owner_foto']); ?>" alt="" class="owner-card-avatar">
                        <?php else: ?>
                            <div class="owner-card-avatar-ph"><?php echo $o_init; ?></div>
                        <?php endif; ?>
                        <div>
                            <div class="owner-card-name"><?php echo htmlspecialchars($project['owner_name']); ?></div>
                            <div class="owner-card-meta"><?php echo htmlspecialchars($project['owner_jurusan'] ?? 'Jurusan belum diatur'); ?></div>
                            <?php if (!empty($project['owner_angkatan'])): ?>
                                <div class="owner-card-meta">Angkatan <?php echo htmlspecialchars($project['owner_angkatan']); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <a href="profile.php?id=<?php echo $project['owner_id']; ?>" class="btn btn-neutral btn-sm" style="width:100%; justify-content:center;">
                        Lihat Profil
                    </a>
                </div>
            </div>

            <!-- Team Members Card -->
            <div class="spec-card">
                <div class="spec-card-header">Anggota Tim (<?php echo count($approved_members); ?>)</div>
                <div style="padding:12px 16px;">
                    <?php if (empty($approved_members)): ?>
                        <p style="font-size:0.875rem; color:var(--color-text-muted); text-align:center; padding:12px 0;">
                            Belum ada anggota tim.
                        </p>
                    <?php else: ?>
                        <div class="member-list">
                            <?php foreach ($approved_members as $m):
                                $m_parts = explode(' ', $m['name']);
                                $m_init  = strtoupper(substr($m_parts[0],0,1).(isset($m_parts[1])?substr($m_parts[1],0,1):''));
                            ?>
                            <div class="member-item" onclick="window.location.href='profile.php?id=<?php echo $m['id']; ?>'">
                                <?php if (!empty($m['foto']) && file_exists('uploads/' . $m['foto'])): ?>
                                    <img src="uploads/<?php echo htmlspecialchars($m['foto']); ?>" alt="" class="member-avatar">
                                <?php else: ?>
                                    <div class="member-avatar-ph"><?php echo $m_init; ?></div>
                                <?php endif; ?>
                                <div>
                                    <div class="member-name"><?php echo htmlspecialchars($m['name']); ?></div>
                                    <div class="member-jurusan"><?php echo htmlspecialchars($m['jurusan'] ?? ''); ?></div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div><!-- /.detail-sidebar -->
    </div><!-- /.detail-layout -->

</div>

<style>
.detail-breadcrumb {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 24px;
    flex-wrap: wrap;
    gap: 12px;
}
.detail-back {
    font-size: 0.875rem;
    font-weight: 600;
    color: var(--color-text-secondary);
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: color 0.2s ease;
}
.detail-back:hover { color: var(--color-primary); }
.detail-breadcrumb-actions { display: flex; gap: 10px; flex-wrap: wrap; }
</style>

<?php require_once 'includes/footer.php'; ?>
