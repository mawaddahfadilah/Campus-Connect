<?php
$page_title = "Lamaran Saya - CampusConnect";
$meta_description = "Lihat status pendaftaran kolaborasi project Anda di CampusConnect.";
require_once 'includes/functions.php';
require_login();

// Redirect admins as they do not apply to projects
if (is_admin()) {
    header("Location: admin-dashboard.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle cancel application
if (isset($_GET['action']) && $_GET['action'] === 'cancel' && isset($_GET['id'])) {
    $application_id = intval($_GET['id']);
    try {
        // Fetch application first to check ownership
        $check_stmt = $pdo->prepare("SELECT pa.*, p.title FROM project_applications pa 
                                     JOIN projects p ON pa.project_id = p.id 
                                     WHERE pa.id = ? AND pa.applicant_id = ?");
        $check_stmt->execute([$application_id, $user_id]);
        $app = $check_stmt->fetch();

        if ($app) {
            // Delete application
            $del_stmt = $pdo->prepare("DELETE FROM project_applications WHERE id = ?");
            $del_stmt->execute([$application_id]);
            
            log_activity('Application Cancelled', "User cancelled application for project '{$app['title']}'.");
            set_flash_message('success', 'Lamaran Anda berhasil dibatalkan.');
        } else {
            set_flash_message('error', 'Lamaran tidak ditemukan atau Anda tidak memiliki akses.');
        }
    } catch (PDOException $e) {
        set_flash_message('error', 'Gagal membatalkan lamaran.');
    }
    header("Location: my-applications.php");
    exit();
}

// Fetch all applications
$applications = [];
try {
    $query = "SELECT 
                pa.id as application_id,
                pa.motivation,
                pa.status as application_status,
                pa.applied_at,
                p.id as project_id,
                p.title as project_title,
                p.category as project_category,
                p.status as project_status,
                p.contact_link,
                u.id as owner_id,
                u.name as owner_name,
                u.email as owner_email,
                u.foto as owner_foto
              FROM project_applications pa
              JOIN projects p ON pa.project_id = p.id
              JOIN users u ON p.owner_id = u.id
              WHERE pa.applicant_id = ?
              ORDER BY pa.applied_at DESC";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$user_id]);
    $applications = $stmt->fetchAll();
} catch (PDOException $e) {
    set_flash_message('error', 'Gagal memuat daftar lamaran.');
}

require_once 'includes/header.php';
?>

<div class="app-container">
    <!-- Page Header -->
    <div class="page-header animate-fade-in">
        <div class="page-header-text">
            <h1>Lamaran Saya</h1>
            <p>Pantau status lamaran kolaborasi dan hubungi pemilik project yang menyetujui lamaran Anda.</p>
        </div>
        <a href="feed.php" class="btn btn-secondary" style="flex-shrink:0;"><i class="fa-solid fa-compass"></i> Jelajahi Project</a>
    </div>

    <!-- Application List -->
    <div class="my-applications-list animate-fade-in" style="margin-top: 24px; display: grid; gap: 20px;">
        <?php if (empty($applications)): ?>
            <div class="empty-state card">
                <div class="empty-state-icon"><i class="fa-solid fa-paper-plane"></i></div>
                <div class="empty-state-title">Belum ada lamaran terkirim</div>
                <p class="empty-state-desc">Jelajahi project kolaborasi yang aktif di feed dan kirimkan lamaran Anda.</p>
                <a href="feed.php" class="btn btn-primary">Cari Project</a>
            </div>
        <?php else: ?>
            <?php foreach ($applications as $app): 
                // Category badge class
                $cat_lower = strtolower($app['project_category']);
                $cat_map = [
                    'pkm' => 'pkm',
                    'p2mw' => 'p2mw',
                    'lomba' => 'lomba',
                    'startup' => 'startup',
                    'volunteer' => 'volunteer',
                    'organisasi' => 'organisasi',
                    'event kampus' => 'event'
                ];
                $badge_cls = isset($cat_map[$cat_lower]) ? 'badge-' . $cat_map[$cat_lower] : 'badge-lainnya';

                // Status Badge class and text
                $status_text = 'Pending';
                $status_cls = 'badge-warning';
                if ($app['application_status'] === 'approved') {
                    $status_text = 'Diterima';
                    $status_cls = 'badge-success';
                } elseif ($app['application_status'] === 'rejected') {
                    $status_text = 'Ditolak';
                    $status_cls = 'badge-danger';
                }

                // Initial for Owner avatar placeholder
                $parts = explode(' ', $app['owner_name']);
                $owner_initials = strtoupper(substr($parts[0], 0, 1) . (isset($parts[1]) ? substr($parts[1], 0, 1) : ''));
            ?>
                <div class="card app-card" style="padding: 24px; position: relative;">
                    <!-- Top Section with badges -->
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 14px; flex-wrap: wrap;">
                        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                            <span class="badge <?php echo $badge_cls; ?>"><?php echo htmlspecialchars($app['project_category']); ?></span>
                            <span class="badge <?php echo $status_cls; ?>" style="font-weight: 600;"><?php echo $status_text; ?></span>
                        </div>
                        <span style="font-size: 0.8rem; color: var(--color-text-muted);">
                            Dikirim pada <?php echo date('d M Y, H:i', strtotime($app['applied_at'])); ?>
                        </span>
                    </div>

                    <!-- Project Title -->
                    <h3 style="font-size: 1.25rem; font-weight: 700; margin: 0 0 10px 0; line-height: 1.4;">
                        <a href="project-detail.php?id=<?php echo $app['project_id']; ?>" class="link-primary" style="text-decoration: none;">
                            <?php echo htmlspecialchars($app['project_title']); ?>
                        </a>
                    </h3>

                    <!-- Owner Info Section -->
                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 18px; border-bottom: 1px solid var(--color-border); padding-bottom: 12px;">
                        <?php if (!empty($app['owner_foto']) && file_exists('uploads/' . $app['owner_foto'])): ?>
                            <img src="uploads/<?php echo htmlspecialchars($app['owner_foto']); ?>" alt="Avatar" style="width: 32px; height: 32px; border-radius: 50%; object-fit: cover;">
                        <?php else: ?>
                            <div style="width: 32px; height: 32px; border-radius: 50%; background: var(--color-primary); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 0.8rem; font-weight: 700;">
                                <?php echo htmlspecialchars($owner_initials); ?>
                            </div>
                        <?php endif; ?>
                        <div>
                            <span style="font-size: 0.85rem; color: var(--color-text-muted);">Pemilik Project:</span>
                            <a href="profile.php?id=<?php echo $app['owner_id']; ?>" class="link-primary" style="font-size: 0.85rem; font-weight: 600; margin-left: 2px;">
                                <?php echo htmlspecialchars($app['owner_name']); ?>
                            </a>
                        </div>
                    </div>

                    <!-- Motivation Letter Box -->
                    <div style="background: var(--color-bg); border-radius: 6px; padding: 14px; margin-bottom: 20px; border-left: 3px solid var(--color-border);">
                        <div style="font-size: 0.8rem; font-weight: 700; color: var(--color-text-secondary); margin-bottom: 4px;">Pesan Motivasi Anda:</div>
                        <p style="font-size: 0.875rem; color: var(--color-text-secondary); margin: 0; line-height: 1.5; white-space: pre-line;">
                            <?php echo htmlspecialchars($app['motivation']); ?>
                        </p>
                    </div>

                    <!-- Footer / Actions -->
                    <div style="display: flex; justify-content: flex-end; gap: 12px; align-items: center; flex-wrap: wrap;">
                        <?php if ($app['application_status'] === 'approved'): ?>
                            <?php if (!empty($app['contact_link'])): ?>
                                <a href="<?php echo htmlspecialchars($app['contact_link']); ?>" target="_blank" class="btn btn-primary btn-sm">
                                    <i class="fa-solid fa-comments"></i> Hubungi Pemilik Project
                                </a>
                            <?php else: ?>
                                <a href="mailto:<?php echo htmlspecialchars($app['owner_email']); ?>" class="btn btn-primary btn-sm">
                                    <i class="fa-regular fa-envelope"></i> Email Pemilik Project
                                </a>
                            <?php endif; ?>
                        <?php elseif ($app['application_status'] === 'pending'): ?>
                            <a href="my-applications.php?action=cancel&id=<?php echo $app['application_id']; ?>" 
                               class="btn btn-neutral btn-sm" 
                               onclick="return confirm('Apakah Anda yakin ingin membatalkan lamaran ini?');"
                               style="color: var(--color-red);">
                                <i class="fa-regular fa-trash-can"></i> Batalkan Lamaran
                            </a>
                        <?php else: ?>
                            <span style="font-size: 0.85rem; color: var(--color-text-muted);">
                                <i class="fa-solid fa-circle-info"></i> Lamaran ditolak pemilik project.
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
