<?php
require_once 'includes/functions.php';
require_admin();

$search = sanitize($_GET['q'] ?? '');
$error = '';

// Handle Delete Project POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $del_proj_id = intval($_POST['project_id']);
    
    try {
        // Fetch project name for logs
        $proj_stmt = $pdo->prepare("SELECT title FROM projects WHERE id = ?");
        $proj_stmt->execute([$del_proj_id]);
        $del_proj = $proj_stmt->fetch();

        if ($del_proj) {
            // Delete project (cascade drops project_skills and applications automatically)
            $del_stmt = $pdo->prepare("DELETE FROM projects WHERE id = ?");
            $del_stmt->execute([$del_proj_id]);

            log_activity('Project Deleted by Admin', "Project \"{$del_proj['title']}\" (ID {$del_proj_id}) deleted by Admin ID {$_SESSION['user_id']}.");
            set_flash_message('success', 'Project kolaborasi "' . htmlspecialchars($del_proj['title']) . '" berhasil dihapus.');
            header("Location: admin-projects.php");
            exit();
        } else {
            $error = 'Project tidak ditemukan.';
        }
    } catch (PDOException $e) {
        $error = 'Gagal menghapus project: ' . $e->getMessage();
    }
}

// Fetch projects list
$proj_query = "SELECT p.*, u.name as owner_name 
               FROM projects p 
               JOIN users u ON p.owner_id = u.id";
$params = [];

if (!empty($search)) {
    $proj_query .= " WHERE p.title LIKE :q OR p.description LIKE :q OR p.category LIKE :q OR u.name LIKE :q";
    $params['q'] = '%' . $search . '%';
}

$proj_query .= " ORDER BY p.id DESC";

try {
    $stmt = $pdo->prepare($proj_query);
    $stmt->execute($params);
    $projects_list = $stmt->fetchAll();
} catch (PDOException $e) {
    set_flash_message('error', 'Gagal memuat daftar project.');
    $projects_list = [];
}

require_once 'includes/header.php';
?>

<div class="app-container">
    <div class="feed-header animate-fade-in">
        <div class="feed-title-area">
            <h2>Kelola Project Kolaborasi</h2>
            <p>Monitor dan hapus postingan project kolaborasi yang tidak sesuai ketentuan</p>
        </div>
        <a href="admin-dashboard.php" class="btn btn-secondary"><i class="fa-solid fa-gauge"></i> Dashboard</a>
    </div>

    <!-- Search bar -->
    <div class="search-filter-bar animate-fade-in" style="grid-template-columns: 1fr; margin-top: 20px;">
        <form action="admin-projects.php" method="GET" style="display: flex; gap: 8px;">
            <input type="text" name="q" class="form-input" placeholder="Cari judul project, deskripsi, kategori, atau nama owner..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-magnifying-glass"></i> Cari</button>
            <?php if (!empty($search)): ?>
                <a href="admin-projects.php" class="btn btn-secondary"><i class="fa-solid fa-rotate-left"></i> Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <?php if (!empty($error)): ?>
        <div class="flash-banner flash-error animate-fade-in">
            <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <!-- Project Table -->
    <div class="admin-table-container animate-fade-in" style="animation-delay: 0.1s; margin-top: 20px;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Judul Project</th>
                    <th>Owner (Mahasiswa)</th>
                    <th>Kategori</th>
                    <th>Kuota Rekrutmen</th>
                    <th>Deadline</th>
                    <th>Status</th>
                    <th style="text-align: right;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($projects_list)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; color: var(--text-secondary); padding: 40px;">Tidak ada project terdaftar yang cocok dengan kriteria.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($projects_list as $p): 
                        $status_badge = '';
                        if ($p['status'] === 'Open') {
                            $status_badge = '<span class="project-status status-open">Open</span>';
                        } else {
                            $status_badge = '<span class="project-status status-closed">Closed</span>';
                        }
                    ?>
                        <tr>
                            <td>
                                <a href="project-detail.php?id=<?php echo $p['id']; ?>" style="font-weight: 600; text-decoration: underline;">
                                    <?php echo htmlspecialchars($p['title']); ?>
                                </a>
                            </td>
                            <td>
                                <a href="profile.php?id=<?php echo $p['owner_id']; ?>" style="text-decoration: underline;">
                                    <?php echo htmlspecialchars($p['owner_name']); ?>
                                </a>
                            </td>
                            <td><span class="project-category" style="padding: 2px 6px; font-size: 0.75rem; font-weight: 600;"><?php echo htmlspecialchars($p['category']); ?></span></td>
                            <td><?php echo htmlspecialchars($p['slots']); ?> Slot</td>
                            <td><?php echo date('d M Y', strtotime($p['deadline'])); ?></td>
                            <td><?php echo $status_badge; ?></td>
                            <td style="text-align: right;">
                                <form action="admin-projects.php" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus project ini secara permanen dari platform?');" style="display: inline-block;">
                                    <input type="hidden" name="project_id" value="<?php echo $p['id']; ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        <i class="fa-regular fa-trash-can"></i> Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
