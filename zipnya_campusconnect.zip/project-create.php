<?php
require_once 'includes/functions.php';
require_login();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title'] ?? '');
    $category = sanitize($_POST['category'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $slots = isset($_POST['slots']) ? intval($_POST['slots']) : 0;
    $deadline = sanitize($_POST['deadline'] ?? '');
    $contact_link = sanitize($_POST['contact_link'] ?? '');
    $skills_input = sanitize($_POST['skills'] ?? ''); // Comma-separated list of tags

    // Validations
    $allowed_categories = ['PKM', 'P2MW', 'Lomba', 'Startup', 'Volunteer', 'Organisasi', 'Event Kampus', 'Lainnya'];
    
    if (empty($title) || empty($category) || empty($description) || $slots <= 0 || empty($deadline)) {
        $error = 'Semua field wajib diisi (kecuali link kontak).';
    } elseif (!in_array($category, $allowed_categories)) {
        $error = 'Kategori tidak valid.';
    } elseif (strtotime($deadline) < strtotime(date('Y-m-d'))) {
        $error = 'Deadline pendaftaran tidak boleh di masa lalu.';
    } else {
        try {
            $pdo->beginTransaction();

            // Insert project
            $stmt = $pdo->prepare("INSERT INTO projects (owner_id, title, category, description, slots, deadline, status, contact_link) VALUES (?, ?, ?, ?, ?, ?, 'Open', ?)");
            $stmt->execute([
                $_SESSION['user_id'],
                $title,
                $category,
                $description,
                $slots,
                $deadline,
                !empty($contact_link) ? $contact_link : null
            ]);

            $project_id = $pdo->lastInsertId();

            // Insert project skills
            if (!empty($skills_input)) {
                $skills_array = array_unique(array_filter(array_map('trim', explode(',', $skills_input))));
                $ins_skill = $pdo->prepare("INSERT INTO project_skills (project_id, skill_name) VALUES (?, ?)");
                foreach ($skills_array as $skill) {
                    if (!empty($skill)) {
                        $ins_skill->execute([$project_id, $skill]);
                    }
                }
            }

            $pdo->commit();

            log_activity('Project Created', "Project \"$title\" created by user ID {$_SESSION['user_id']}.");
            
            set_flash_message('success', 'Postingan project kolaborasi berhasil dibuat!');
            header("Location: project-detail.php?id=" . $project_id);
            exit();

        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = 'Gagal menyimpan project: ' . $e->getMessage();
        }
    }
}

require_once 'includes/header.php';
?>

<div class="app-container">
    <div class="feed-header animate-fade-in">
        <div class="feed-title-area">
            <h2>Buat Project Kolaborasi Baru</h2>
            <p>Bagikan ide project Anda dan temukan rekan kolaborator yang tepat di kampus</p>
        </div>
        <a href="feed.php" class="btn btn-secondary"><i class="fa-solid fa-arrow-left"></i> Kembali ke Feed</a>
    </div>

    <?php if (!empty($error)): ?>
        <div class="flash-banner flash-error animate-fade-in">
            <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <div class="card animate-fade-in" style="margin-top: 20px;">
        <form action="project-create.php" method="POST" class="validate-form">
            
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label for="title" class="form-label">Judul Project</label>
                    <input type="text" name="title" id="title" class="form-input" placeholder="Contoh: Pengembangan Platform EduTech UI" required value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>">
                </div>

                <div class="form-group">
                    <label for="category" class="form-label">Kategori Project</label>
                    <select name="category" id="category" class="form-input" required>
                        <option value="" disabled selected>Pilih Kategori</option>
                        <option value="PKM" <?php echo (isset($_POST['category']) && $_POST['category'] == 'PKM') ? 'selected' : ''; ?>>PKM</option>
                        <option value="P2MW" <?php echo (isset($_POST['category']) && $_POST['category'] == 'P2MW') ? 'selected' : ''; ?>>P2MW</option>
                        <option value="Lomba" <?php echo (isset($_POST['category']) && $_POST['category'] == 'Lomba') ? 'selected' : ''; ?>>Lomba</option>
                        <option value="Startup" <?php echo (isset($_POST['category']) && $_POST['category'] == 'Startup') ? 'selected' : ''; ?>>Startup</option>
                        <option value="Volunteer" <?php echo (isset($_POST['category']) && $_POST['category'] == 'Volunteer') ? 'selected' : ''; ?>>Volunteer</option>
                        <option value="Organisasi" <?php echo (isset($_POST['category']) && $_POST['category'] == 'Organisasi') ? 'selected' : ''; ?>>Organisasi</option>
                        <option value="Event Kampus" <?php echo (isset($_POST['category']) && $_POST['category'] == 'Event Kampus') ? 'selected' : ''; ?>>Event Kampus</option>
                        <option value="Lainnya" <?php echo (isset($_POST['category']) && $_POST['category'] == 'Lainnya') ? 'selected' : ''; ?>>Lainnya</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="description" class="form-label">Deskripsi Lengkap Project</label>
                <textarea name="description" id="description" class="form-input" rows="6" placeholder="Jelaskan latar belakang project, tujuan, rencana kerja, dan ekspektasi dari tim yang akan bergabung..." required style="resize: vertical; font-family: inherit;"><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <div class="form-group">
                    <label for="slots" class="form-label">Jumlah Rekan yang Dicari (Slot)</label>
                    <input type="number" name="slots" id="slots" class="form-input" placeholder="Contoh: 3" min="1" required value="<?php echo isset($_POST['slots']) ? htmlspecialchars($_POST['slots']) : '1'; ?>">
                    <small class="form-help">Jumlah orang yang ingin Anda rekrut ke dalam tim.</small>
                </div>

                <div class="form-group">
                    <label for="deadline" class="form-label">Deadline Pendaftaran</label>
                    <input type="date" name="deadline" id="deadline" class="form-input" required value="<?php echo isset($_POST['deadline']) ? htmlspecialchars($_POST['deadline']) : ''; ?>">
                    <small class="form-help">Setelah tanggal ini, project otomatis ditutup.</small>
                </div>
            </div>

            <div class="form-group">
                <label for="contact_link" class="form-label">Tautan Komunikasi Utama (Opsional)</label>
                <input type="url" name="contact_link" id="contact_link" class="form-input" placeholder="Contoh: https://chat.whatsapp.com/... atau https://discord.gg/..." value="<?php echo isset($_POST['contact_link']) ? htmlspecialchars($_POST['contact_link']) : ''; ?>">
                <small class="form-help">Tautan ini HANYA dapat dilihat oleh pendaftar yang statusnya disetujui (Approved) untuk mempermudah koordinasi awal.</small>
            </div>

            <!-- Dynamic Tags Input for Project Skills -->
            <div class="form-group">
                <label class="form-label">Keahlian yang Dibutuhkan</label>
                <div class="tags-input-container">
                    <!-- Badges render here -->
                    <input type="text" id="skill_type_input" placeholder="Ketik keahlian lalu tekan Enter atau Koma">
                </div>
                <input type="hidden" name="skills" value="<?php echo isset($_POST['skills']) ? htmlspecialchars($_POST['skills']) : ''; ?>">
                <small class="form-help">Kebutuhan spesifik tim Anda (contoh: UI/UX, Flutter, Python, Public Speaking).</small>
                
                <div style="margin-top: 14px;">
                    <div style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 8px; font-weight: 600;">Saran Tag Keahlian:</div>
                    <div class="predefined-tags-list">
                        <button type="button" class="predefined-tag-btn" data-tag="UI/UX">UI/UX</button>
                        <button type="button" class="predefined-tag-btn" data-tag="Figma">Figma</button>
                        <button type="button" class="predefined-tag-btn" data-tag="HTML">HTML</button>
                        <button type="button" class="predefined-tag-btn" data-tag="CSS">CSS</button>
                        <button type="button" class="predefined-tag-btn" data-tag="JavaScript">JavaScript</button>
                        <button type="button" class="predefined-tag-btn" data-tag="PHP">PHP</button>
                        <button type="button" class="predefined-tag-btn" data-tag="MySQL">MySQL</button>
                        <button type="button" class="predefined-tag-btn" data-tag="Python">Python</button>
                        <button type="button" class="predefined-tag-btn" data-tag="Public Speaking">Public Speaking</button>
                        <button type="button" class="predefined-tag-btn" data-tag="Copywriting">Copywriting</button>
                        <button type="button" class="predefined-tag-btn" data-tag="Product Management">Product Management</button>
                        <button type="button" class="predefined-tag-btn" data-tag="Pitch Deck">Pitch Deck</button>
                    </div>
                </div>
            </div>

            <!-- Action buttons -->
            <div style="display: flex; gap: 16px; justify-content: flex-end; margin-top: 30px; border-top: 1px solid var(--card-border); padding-top: 20px;">
                <a href="feed.php" class="btn btn-secondary">Batal</a>
                <button type="submit" class="btn btn-primary">Publikasikan Project</button>
            </div>

        </form>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
