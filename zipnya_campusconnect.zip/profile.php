<?php
require_once 'includes/functions.php';
require_login();

$user_id        = isset($_GET['id']) ? intval($_GET['id']) : $_SESSION['user_id'];
$is_own_profile = ($user_id === $_SESSION['user_id']);

$user = $skills = $my_projects = $joined_projects = $bookmarked_projects = $admin_logs = $portfolio_items = [];

try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!$user) {
        set_flash_message('error', 'Profil tidak ditemukan.');
        header("Location: feed.php"); exit();
    }

    if ($user['role'] === 'admin') {
        $log_stmt  = $pdo->query("SELECT * FROM activity_logs ORDER BY id DESC LIMIT 10");
        $admin_logs = $log_stmt->fetchAll();
    } else {
        $sk = $pdo->prepare("SELECT skill_name FROM user_skills WHERE user_id = ?");
        $sk->execute([$user_id]);
        $skills = $sk->fetchAll(PDO::FETCH_COLUMN);

        $pj = $pdo->prepare("SELECT * FROM projects WHERE owner_id = ? ORDER BY id DESC");
        $pj->execute([$user_id]);
        $my_projects = $pj->fetchAll();

        $jj = $pdo->prepare("SELECT p.*, u.name as owner_name FROM projects p
                              JOIN project_applications pa ON p.id = pa.project_id
                              JOIN users u ON p.owner_id = u.id
                              WHERE pa.applicant_id = ? AND pa.status = 'approved' ORDER BY p.id DESC");
        $jj->execute([$user_id]);
        $joined_projects = $jj->fetchAll();

        if ($is_own_profile) {
            $bm = $pdo->prepare("SELECT p.*, u.name as owner_name, u.foto as owner_foto
                                  FROM projects p
                                  JOIN project_bookmarks pb ON p.id = pb.project_id
                                  JOIN users u ON p.owner_id = u.id
                                  WHERE pb.user_id = ? ORDER BY pb.created_at DESC");
            $bm->execute([$user_id]);
            $bookmarked_projects = $bm->fetchAll();
        }

        // Fetch user portfolio items
        try {
            $pf = $pdo->prepare("SELECT * FROM user_portfolio WHERE user_id = ? ORDER BY id DESC");
            $pf->execute([$user_id]);
            $portfolio_items = $pf->fetchAll();
        } catch (PDOException $e) { /* fail silently if table does not exist yet */ }
    }
} catch (PDOException $e) {
    set_flash_message('error', 'Terjadi kesalahan database.');
    header("Location: feed.php"); exit();
}

// Completeness
$completeness = 0;
if ($user['role'] !== 'admin') {
    $completeness  = 20;
    if (!empty($user['bio']))      $completeness += 20;
    if (!empty($user['jurusan']))  $completeness += 20;
    if (!empty($user['angkatan'])) $completeness += 20;
    if (!empty($skills))           $completeness += 20;
}

$parts    = explode(' ', $user['name']);
$initials = strtoupper(substr($parts[0],0,1).(isset($parts[1])?substr($parts[1],0,1):''));

// Helper: render mini project card
function render_mini_card($project, $pdo, $is_own = false, $show_bookmark = false) {
    $p_skills = [];
    try {
        $ps = $pdo->prepare("SELECT skill_name FROM project_skills WHERE project_id = ?");
        $ps->execute([$project['id']]);
        $p_skills = $ps->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {}

    $cat_lower = strtolower($project['category']);
    $cat_map   = ['pkm'=>'pkm','p2mw'=>'p2mw','lomba'=>'lomba','startup'=>'startup','volunteer'=>'volunteer','organisasi'=>'organisasi','event kampus'=>'event'];
    $badge_cls = isset($cat_map[$cat_lower]) ? 'badge-'.$cat_map[$cat_lower] : 'badge-lainnya';
    $st_badge  = ($project['status'] === 'Open') ? 'badge-open' : 'badge-closed';
    ?>
    <a href="project-detail.php?id=<?php echo $project['id']; ?>" class="project-card">
        <div class="project-card-top">
            <div class="project-card-badges">
                <span class="badge <?php echo $badge_cls; ?>"><?php echo htmlspecialchars($project['category']); ?></span>
                <span class="badge <?php echo $st_badge; ?>"><?php echo htmlspecialchars($project['status']); ?></span>
            </div>
            <?php if ($show_bookmark): ?>
                <span onclick="event.stopPropagation(); window.location.href='project-bookmark.php?id=<?php echo $project['id']; ?>&redirect=profile'"
                   class="bookmark-icon-card bookmarked" title="Hapus Penanda">
                    <i class="fa-solid fa-bookmark"></i>
                </span>
            <?php endif; ?>
        </div>
        <div class="project-title"><?php echo htmlspecialchars($project['title']); ?></div>
        <div class="project-desc"><?php echo htmlspecialchars($project['description']); ?></div>
        <?php if (!empty($p_skills)): ?>
        <div class="skill-tags-list">
            <?php foreach (array_slice($p_skills,0,3) as $sk): ?>
                <span class="skill-tag"><?php echo htmlspecialchars($sk); ?></span>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="project-card-footer">
            <span class="project-meta-item" style="font-size:0.8125rem; color:var(--color-text-muted);">
                <i class="fa-regular fa-calendar"></i>
                <?php echo date('d M Y', strtotime($project['deadline'] ?? $project['created_at'])); ?>
            </span>
            <?php if ($is_own): ?>
                <a href="project-manage.php?id=<?php echo $project['id']; ?>"
                   class="btn btn-neutral btn-sm" onclick="event.stopPropagation();">
                    Kelola Tim
                </a>
            <?php else: ?>
                <span class="link-arrow">Lihat <i class="fa-solid fa-arrow-right"></i></span>
            <?php endif; ?>
        </div>
    </a>
    <?php
}

require_once 'includes/header.php';
?>

<div class="app-container">

    <div class="profile-page-layout animate-fade-in">

        <!-- ===== SIDEBAR ===== -->
        <aside class="profile-sidebar">

            <!-- Avatar & Name -->
            <div class="profile-sidebar-section" style="text-align:center; padding:20px 16px;">
                <?php if (!empty($user['foto']) && file_exists('uploads/' . $user['foto'])): ?>
                    <img src="uploads/<?php echo htmlspecialchars($user['foto']); ?>"
                         alt="" class="profile-avatar-img" onerror="this.style.display='none';">
                <?php else: ?>
                    <div class="profile-avatar-ph"><?php echo htmlspecialchars($initials); ?></div>
                <?php endif; ?>

                <h1 class="profile-name"><?php echo htmlspecialchars($user['name']); ?></h1>

                <?php if ($user['role'] === 'admin'): ?>
                    <div class="profile-academic" style="color:var(--color-red); font-weight:600;">
                        <i class="fa-solid fa-user-shield"></i> Administrator
                    </div>
                <?php else: ?>
                    <?php if (!empty($user['universitas'])): ?>
                        <div class="profile-university">
                            <i class="fa-solid fa-graduation-cap"></i>
                            <?php echo htmlspecialchars($user['universitas']); ?>
                        </div>
                    <?php endif; ?>
                    <div class="profile-academic">
                        <?php echo htmlspecialchars($user['jurusan'] ?? 'Jurusan belum diatur'); ?>
                        <?php if (!empty($user['angkatan'])): ?>
                            &nbsp;·&nbsp; Angkatan <?php echo htmlspecialchars($user['angkatan']); ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($user['bio'])): ?>
                    <p class="profile-bio" style="margin-top:12px;">
                        <?php echo nl2br(htmlspecialchars($user['bio'])); ?>
                    </p>
                <?php endif; ?>

                <?php if ($is_own_profile): ?>
                    <a href="settings.php" class="btn btn-secondary btn-sm" style="width:100%; margin-top:16px;">
                        <i class="fa-regular fa-pen-to-square"></i> Edit Profil
                    </a>
                <?php endif; ?>
            </div>

            <!-- Profile Completeness -->
            <?php if ($is_own_profile && $user['role'] !== 'admin'): ?>
            <div class="profile-sidebar-section">
                <span class="profile-sidebar-label">Kelengkapan Profil</span>
                <div class="completeness-bar-container">
                    <div class="completeness-bar-header">
                        <span>Progress</span>
                        <span><?php echo $completeness; ?>%</span>
                    </div>
                    <div class="progress-track">
                        <div class="progress-fill" style="width:<?php echo $completeness; ?>%;"></div>
                    </div>
                    <?php if ($completeness < 100): ?>
                        <p style="font-size:0.78rem; color:var(--color-text-muted); margin-top:8px;">
                            Lengkapi profil agar lebih mudah ditemukan oleh Project Owner.
                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Skills -->
            <?php if ($user['role'] !== 'admin'): ?>
            <div class="profile-sidebar-section">
                <span class="profile-sidebar-label">Keahlian</span>
                <?php if (empty($skills)): ?>
                    <p style="font-size:0.8125rem; color:var(--color-text-muted);">Belum ada keahlian.</p>
                    <?php if ($is_own_profile): ?>
                        <a href="settings.php" class="btn btn-ghost btn-sm" style="padding:4px 0; margin-top:4px; font-size:0.8rem;">
                            + Tambah Keahlian
                        </a>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="skill-tags-list">
                        <?php foreach ($skills as $sk): ?>
                            <span class="skill-tag"><?php echo htmlspecialchars($sk); ?></span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Stats -->
            <div class="profile-sidebar-section">
                <span class="profile-sidebar-label">Statistik</span>
                <div style="display:flex; flex-direction:column; gap:10px;">
                    <div style="display:flex; justify-content:space-between; font-size:0.875rem;">
                        <span style="color:var(--color-text-secondary);"><i class="fa-solid fa-folder" style="width:16px;"></i> Project Dibuat</span>
                        <strong><?php echo count($my_projects); ?></strong>
                    </div>
                    <div style="display:flex; justify-content:space-between; font-size:0.875rem;">
                        <span style="color:var(--color-text-secondary);"><i class="fa-solid fa-users" style="width:16px;"></i> Project Diikuti</span>
                        <strong><?php echo count($joined_projects); ?></strong>
                    </div>
                    <?php if ($is_own_profile): ?>
                    <div style="display:flex; justify-content:space-between; font-size:0.875rem;">
                        <span style="color:var(--color-text-secondary);"><i class="fa-regular fa-bookmark" style="width:16px;"></i> Disimpan</span>
                        <strong><?php echo count($bookmarked_projects); ?></strong>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($user['role'] === 'admin'): ?>
            <div class="profile-sidebar-section">
                <span class="profile-sidebar-label">Panel Admin</span>
                <a href="admin-dashboard.php" class="btn btn-secondary btn-sm" style="width:100%;">
                    <i class="fa-solid fa-gauge-high"></i> Buka Dashboard
                </a>
            </div>
            <?php endif; ?>

        </aside>

        <!-- ===== MAIN CONTENT ===== -->
        <div class="profile-main">

            <?php if ($user['role'] === 'admin'): ?>
                <!-- Admin Log Tab -->
                <div class="profile-tabs">
                    <div class="profile-tab active" data-tab="admin-activity-tab">Log Aktivitas</div>
                </div>
                <div id="admin-activity-tab" class="tab-content active">
                    <div class="admin-table-card">
                        <div class="admin-table-header">
                            <span class="admin-table-title">Riwayat Aktivitas Sistem</span>
                        </div>
                        <div class="log-list">
                            <?php if (empty($admin_logs)): ?>
                                <div class="empty-state" style="padding:32px;">
                                    <div class="empty-state-icon"><i class="fa-solid fa-clock-rotate-left"></i></div>
                                    <div class="empty-state-title">Belum ada log</div>
                                </div>
                            <?php else: ?>
                                <?php foreach ($admin_logs as $log): ?>
                                <div class="log-item">
                                    <span>
                                        <span class="log-action"><?php echo htmlspecialchars($log['action']); ?></span>
                                        <span class="log-detail">— <?php echo htmlspecialchars($log['details']); ?></span>
                                    </span>
                                    <span class="log-time"><?php echo date('d M, H:i', strtotime($log['created_at'])); ?></span>
                                </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            <?php else: ?>
                <!-- Student Tabs -->
                <div class="profile-tabs">
                    <div class="profile-tab active" data-tab="owned-projects">
                        Project Dibuat <span class="tab-count"><?php echo count($my_projects); ?></span>
                    </div>
                    <div class="profile-tab" data-tab="joined-projects">
                        Project Diikuti <span class="tab-count"><?php echo count($joined_projects); ?></span>
                    </div>
                    <div class="profile-tab" data-tab="portfolio-tab">
                        Portfolio <span class="tab-count"><?php echo count($portfolio_items); ?></span>
                    </div>
                    <?php if ($is_own_profile): ?>
                    <div class="profile-tab" data-tab="bookmarked-projects-tab">
                        Disimpan <span class="tab-count"><?php echo count($bookmarked_projects); ?></span>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="profile-tab-panels">
                    <!-- Owned Projects -->
                    <div id="owned-projects" class="tab-content active">
                        <?php if (empty($my_projects)): ?>
                            <div class="empty-state card">
                                <div class="empty-state-icon"><i class="fa-solid fa-folder-open"></i></div>
                                <div class="empty-state-title">Belum ada project yang dibuat</div>
                                <p class="empty-state-desc">
                                    <?php echo $is_own_profile ? 'Anda belum membuat project kolaborasi.' : 'Pengguna ini belum membuat project.'; ?>
                                </p>
                                <?php if ($is_own_profile): ?>
                                    <a href="project-create.php" class="btn btn-primary">Buat Project</a>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="project-grid">
                                <?php foreach ($my_projects as $project): ?>
                                    <?php render_mini_card($project, $pdo, $is_own_profile, false); ?>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Joined Projects -->
                    <div id="joined-projects" class="tab-content">
                        <?php if (empty($joined_projects)): ?>
                            <div class="empty-state card">
                                <div class="empty-state-icon"><i class="fa-solid fa-users-slash"></i></div>
                                <div class="empty-state-title">Belum ada project yang diikuti</div>
                                <p class="empty-state-desc">
                                    <?php echo $is_own_profile ? 'Anda belum bergabung di project kolaborasi lain.' : 'Pengguna ini belum bergabung di project manapun.'; ?>
                                </p>
                            </div>
                        <?php else: ?>
                            <div class="project-grid">
                                <?php foreach ($joined_projects as $project): ?>
                                    <?php render_mini_card($project, $pdo, false, false); ?>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Bookmarked -->
                    <?php if ($is_own_profile): ?>
                    <div id="bookmarked-projects-tab" class="tab-content">
                        <?php if (empty($bookmarked_projects)): ?>
                            <div class="empty-state card">
                                <div class="empty-state-icon"><i class="fa-regular fa-bookmark"></i></div>
                                <div class="empty-state-title">Belum ada project yang disimpan</div>
                                <p class="empty-state-desc">Simpan project menarik dari feed untuk diakses cepat di sini.</p>
                                <a href="feed.php" class="btn btn-secondary">Cari Project</a>
                            </div>
                        <?php else: ?>
                            <div class="project-grid">
                                <?php foreach ($bookmarked_projects as $project): ?>
                                    <?php render_mini_card($project, $pdo, false, true); ?>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <!-- Portfolio Tab -->
                    <div id="portfolio-tab" class="tab-content">
                        <?php if (!empty($portfolio_items)): ?>
                            <div class="portfolio-grid">
                                <?php foreach ($portfolio_items as $item): ?>
                                    <div class="card portfolio-card">
                                        <div class="portfolio-img-wrapper" onclick="openLightbox('uploads/<?php echo htmlspecialchars($item['file_name']); ?>', '<?php echo htmlspecialchars(addslashes($item['caption'])); ?>')">
                                            <img src="uploads/<?php echo htmlspecialchars($item['file_name']); ?>" alt="<?php echo htmlspecialchars($item['caption']); ?>" class="portfolio-img">
                                        </div>
                                        <div class="portfolio-info">
                                            <p class="portfolio-caption"><?php echo htmlspecialchars($item['caption']); ?></p>
                                            <span class="portfolio-date"><?php echo date('d M Y', strtotime($item['uploaded_at'])); ?></span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state card">
                                <div class="empty-state-icon"><i class="fa-regular fa-file-image"></i></div>
                                <div class="empty-state-title">Belum ada portfolio</div>
                                <p class="empty-state-desc">
                                    <?php echo $is_own_profile ? 'Unggah sertifikat atau karya Anda di menu <a href="settings.php?tab=portfolio" style="color:var(--color-primary);">Pengaturan</a>.' : 'Pengguna ini belum mengunggah portfolio.'; ?>
                                </p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

        </div><!-- /.profile-main -->
    </div><!-- /.profile-page-layout -->

</div>

<style>
.tab-count {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: var(--color-border);
    color: var(--color-text-muted);
    font-size: 0.7rem;
    font-weight: 700;
    border-radius: 20px;
    padding: 1px 7px;
    margin-left: 4px;
}
.profile-tab.active .tab-count {
    background: var(--color-primary);
    color: #fff;
}
</style>

<!-- Lightbox Modal -->
<div id="lightbox-modal" class="lightbox-modal" onclick="closeLightbox()">
    <span class="lightbox-close" onclick="closeLightbox()">&times;</span>
    <img id="lightbox-img" class="lightbox-content" src="" alt="Portfolio">
    <div id="lightbox-caption" class="lightbox-caption"></div>
</div>

<script>
function openLightbox(src, caption) {
    document.getElementById('lightbox-img').src = src;
    document.getElementById('lightbox-caption').innerText = caption;
    const modal = document.getElementById('lightbox-modal');
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}
function closeLightbox() {
    document.getElementById('lightbox-modal').style.display = 'none';
    document.body.style.overflow = '';
}
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeLightbox();
});
</script>

<?php require_once 'includes/footer.php'; ?>
