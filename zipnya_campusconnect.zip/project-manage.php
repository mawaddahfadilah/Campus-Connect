<?php
require_once 'includes/functions.php';
require_login();

$project_id = isset($_GET['id']) ? intval($_GET['id']) : (isset($_POST['id']) ? intval($_POST['id']) : 0);
$user_id = $_SESSION['user_id'];
$error = '';

try {
    // Fetch project
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$project_id]);
    $project = $stmt->fetch();

    if (!$project) {
        set_flash_message('error', 'Project tidak ditemukan.');
        header("Location: feed.php");
        exit();
    }

    // Check ownership
    if ($project['owner_id'] !== $user_id) {
        set_flash_message('error', 'Anda tidak memiliki hak untuk mengelola project ini.');
        header("Location: feed.php");
        exit();
    }

    // Fetch approved members count
    $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM project_applications WHERE project_id = ? AND status = 'approved'");
    $count_stmt->execute([$project_id]);
    $approved_count = $count_stmt->fetchColumn();

} catch (PDOException $e) {
    set_flash_message('error', 'Database error: ' . $e->getMessage());
    header("Location: feed.php");
    exit();
}

// Handle Approve / Reject Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['application_id']) && isset($_POST['status'])) {
    $app_id = intval($_POST['application_id']);
    $new_status = sanitize($_POST['status']);

    if (!in_array($new_status, ['approved', 'rejected'])) {
        $error = 'Aksi tidak valid.';
    } else {
        try {
            // Fetch application details to verify ownership and check status
            $app_stmt = $pdo->prepare("SELECT pa.*, u.name as applicant_name 
                                       FROM project_applications pa 
                                       JOIN users u ON pa.applicant_id = u.id 
                                       WHERE pa.id = ? AND pa.project_id = ?");
            $app_stmt->execute([$app_id, $project_id]);
            $app = $app_stmt->fetch();

            if (!$app) {
                $error = 'Pendaftaran tidak ditemukan.';
            } elseif ($app['status'] !== 'pending') {
                $error = 'Pendaftaran ini sudah diproses sebelumnya.';
            } else {
                $pdo->beginTransaction();

                if ($new_status === 'approved') {
                    // Check slots
                    if ($approved_count >= $project['slots']) {
                        throw new Exception('Gagal menyetujui: Kuota project sudah terpenuhi.');
                    }

                    // Approve application
                    $update_stmt = $pdo->prepare("UPDATE project_applications SET status = 'approved' WHERE id = ?");
                    $update_stmt->execute([$app_id]);
                    $approved_count++;

                    // If slots are now full, automatically close the project
                    if ($approved_count >= $project['slots']) {
                        $close_stmt = $pdo->prepare("UPDATE projects SET status = 'Closed' WHERE id = ?");
                        $close_stmt->execute([$project_id]);
                        log_activity('Project Auto-Closed', "Project ID {$project_id} automatically closed as slots are filled.");
                    }

                    // Create notification
                    $notif_msg = "Pendaftaran Anda di project <strong>" . htmlspecialchars($project['title']) . "</strong> telah <strong>disetujui</strong>! Silakan klik detail project untuk melihat tautan komunikasi.";
                    add_notification($app['applicant_id'], $notif_msg);

                    log_activity('Application Approved', "Applicant {$app['applicant_name']} approved for project \"{$project['title']}\".");
                    set_flash_message('success', 'Pelamar berhasil disetujui bergabung ke tim.');

                } else {
                    // Reject application
                    $update_stmt = $pdo->prepare("UPDATE project_applications SET status = 'rejected' WHERE id = ?");
                    $update_stmt->execute([$app_id]);

                    // Create notification
                    $notif_msg = "Maaf, pendaftaran Anda di project <strong>" . htmlspecialchars($project['title']) . "</strong> belum disetujui oleh owner.";
                    add_notification($app['applicant_id'], $notif_msg);

                    log_activity('Application Rejected', "Applicant {$app['applicant_name']} rejected for project \"{$project['title']}\".");
                    set_flash_message('info', 'Pelamar telah ditolak.');
                }

                $pdo->commit();
                header("Location: project-manage.php?id=" . $project_id);
                exit();
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = $e->getMessage();
        }
    }
}

// Fetch all applications
try {
    $apps_stmt = $pdo->prepare("SELECT pa.*, u.name as applicant_name, u.foto as applicant_foto, u.jurusan as applicant_jurusan, u.angkatan as applicant_angkatan 
                                 FROM project_applications pa 
                                 JOIN users u ON pa.applicant_id = u.id 
                                 WHERE pa.project_id = ? 
                                 ORDER BY CASE WHEN pa.status = 'pending' THEN 1 ELSE 2 END, pa.applied_at DESC");
    $apps_stmt->execute([$project_id]);
    $applications = $apps_stmt->fetchAll();
} catch (PDOException $e) {
    set_flash_message('error', 'Gagal memuat daftar pelamar.');
    $applications = [];
}

require_once 'includes/header.php';
?>

<div class="app-container">
    <div class="feed-header animate-fade-in">
        <div class="feed-title-area">
            <h2>Kelola Tim & Pelamar</h2>
            <p>Project: <strong><?php echo htmlspecialchars($project['title']); ?></strong></p>
        </div>
        <a href="project-detail.php?id=<?php echo $project['id']; ?>" class="btn btn-secondary"><i class="fa-solid fa-arrow-left"></i> Kembali ke Project</a>
    </div>

    <?php if (!empty($error)): ?>
        <div class="flash-banner flash-error animate-fade-in">
            <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <!-- Summary Specs -->
    <div class="stats-grid animate-fade-in" style="margin-top: 20px; margin-bottom: 30px;">
        <div class="stat-card" style="padding: 16px 20px;">
            <div class="stat-num" style="font-size: 2rem;"><?php echo htmlspecialchars($project['slots']); ?></div>
            <div class="stat-lbl">Kuota Anggota</div>
        </div>
        <div class="stat-card" style="padding: 16px 20px;">
            <div class="stat-num" style="font-size: 2rem; color: var(--secondary);"><?php echo $approved_count; ?></div>
            <div class="stat-lbl">Terisi Saat Ini</div>
        </div>
        <div class="stat-card" style="padding: 16px 20px;">
            <div class="stat-num" style="font-size: 2rem; color: var(--warning);"><?php echo htmlspecialchars($project['slots'] - $approved_count); ?></div>
            <div class="stat-lbl">Slot Tersisa</div>
        </div>
    </div>

    <!-- Applicants List Section -->
    <div class="animate-fade-in" style="animation-delay: 0.1s;">
        <div class="profile-tabs">
            <div class="profile-tab active" data-tab="pending-apps">Pendaftaran Masuk (Pending)</div>
            <div class="profile-tab" data-tab="processed-apps">Riwayat Keputusan (Diterima / Ditolak)</div>
        </div>

        <!-- Pending Applications -->
        <div id="pending-apps" class="tab-content active">
            <?php 
            $pending_count = 0;
            foreach ($applications as $app) {
                if ($app['status'] === 'pending') $pending_count++;
            }

            if ($pending_count === 0): 
            ?>
                <div class="empty-state card">
                    <div class="empty-state-icon"><i class="fa-solid fa-inbox"></i></div>
                    <div class="empty-state-title">Tidak ada pendaftaran baru</div>
                    <p>Belum ada pelamar baru yang mendaftar ke project ini.</p>
                </div>
            <?php else: ?>
                <div style="display: flex; flex-direction: column; gap: 20px;">
                    <?php foreach ($applications as $app): 
                        if ($app['status'] !== 'pending') continue;
                        
                        $app_parts = explode(' ', $app['applicant_name']);
                        $app_init = strtoupper(substr($app_parts[0], 0, 1) . (isset($app_parts[1]) ? substr($app_parts[1], 0, 1) : ''));
                    ?>
                        <div class="card applicant-card animate-fade-in">
                            <div class="applicant-header">
                                <div class="applicant-user-info" onclick="window.location.href='profile.php?id=<?php echo $app['applicant_id']; ?>'" style="cursor: pointer;">
                                    <?php if (!empty($app['applicant_foto']) && file_exists('uploads/' . $app['applicant_foto'])): ?>
                                        <img src="uploads/<?php echo htmlspecialchars($app['applicant_foto']); ?>" alt="Avatar" class="applicant-avatar">
                                    <?php else: ?>
                                        <div class="applicant-avatar" style="background: var(--primary-gradient); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 1.1rem; border-radius: 50%;"><?php echo $app_init; ?></div>
                                    <?php endif; ?>
                                    <div class="applicant-details">
                                        <h4><?php echo htmlspecialchars($app['applicant_name']); ?></h4>
                                        <p><?php echo htmlspecialchars($app['applicant_jurusan'] ?? 'Jurusan belum diatur'); ?> · Angkatan <?php echo htmlspecialchars($app['applicant_angkatan'] ?? '-'); ?></p>
                                    </div>
                                </div>
                                
                                <div style="font-size: 0.8rem; color: var(--text-muted);">
                                    Mendaftar: <?php echo date('d M Y, H:i', strtotime($app['applied_at'])); ?>
                                </div>
                            </div>
                            
                            <div class="applicant-motivation">
                                <strong>Pesan Motivasi:</strong><br>
                                <?php echo nl2br(htmlspecialchars($app['motivation'])); ?>
                            </div>

                            <div class="applicant-actions">
                                <form action="project-manage.php?id=<?php echo $project['id']; ?>" method="POST" style="display: inline-block;">
                                    <input type="hidden" name="application_id" value="<?php echo $app['id']; ?>">
                                    <input type="hidden" name="status" value="rejected">
                                    <button type="submit" class="btn btn-secondary btn-sm" style="border-color: var(--danger); color: var(--danger);" onclick="return confirm('Apakah Anda yakin ingin menolak pelamar ini?');">
                                        <i class="fa-solid fa-xmark"></i> Tolak
                                    </button>
                                </form>
                                
                                <?php if ($approved_count >= $project['slots']): ?>
                                    <button class="btn btn-primary btn-sm" disabled style="opacity: 0.5;" title="Kuota Anggota Penuh">
                                        <i class="fa-solid fa-check"></i> Terima (Kuota Penuh)
                                    </button>
                                <?php else: ?>
                                    <form action="project-manage.php?id=<?php echo $project['id']; ?>" method="POST" style="display: inline-block;">
                                        <input type="hidden" name="application_id" value="<?php echo $app['id']; ?>">
                                        <input type="hidden" name="status" value="approved">
                                        <button type="submit" class="btn btn-primary btn-sm" style="background: var(--primary-gradient);" onclick="return confirm('Apakah Anda yakin ingin menyetujui pelamar ini bergabung ke tim?');">
                                            <i class="fa-solid fa-check"></i> Setujui Gabung
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Processed Applications -->
        <div id="processed-apps" class="tab-content">
            <?php 
            $processed_count = 0;
            foreach ($applications as $app) {
                if ($app['status'] !== 'pending') $processed_count++;
            }

            if ($processed_count === 0): 
            ?>
                <div class="empty-state card">
                    <div class="empty-state-icon"><i class="fa-solid fa-clock-rotate-left"></i></div>
                    <div class="empty-state-title">Belum ada keputusan</div>
                    <p>Anda belum memproses pendaftaran masuk apapun.</p>
                </div>
            <?php else: ?>
                <div class="admin-table-container">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Nama Pelamar</th>
                                <th>Jurusan / Angkatan</th>
                                <th>Tanggal Daftar</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($applications as $app): 
                                if ($app['status'] === 'pending') continue;
                                
                                $status_badge = '';
                                if ($app['status'] === 'approved') {
                                    $status_badge = '<span class="project-status status-open">Diterima</span>';
                                } else {
                                    $status_badge = '<span class="project-status status-closed">Ditolak</span>';
                                }
                            ?>
                                <tr>
                                    <td>
                                        <a href="profile.php?id=<?php echo $app['applicant_id']; ?>" style="font-weight: 600; text-decoration: underline;">
                                            <?php echo htmlspecialchars($app['applicant_name']); ?>
                                        </a>
                                    </td>
                                    <td><?php echo htmlspecialchars($app['applicant_jurusan'] ?? '-'); ?> · <?php echo htmlspecialchars($app['applicant_angkatan'] ?? '-'); ?></td>
                                    <td><?php echo date('d M Y', strtotime($app['applied_at'])); ?></td>
                                    <td><?php echo $status_badge; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

</div>

<?php require_once 'includes/footer.php'; ?>
