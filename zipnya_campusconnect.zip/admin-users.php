<?php
require_once 'includes/functions.php';
require_admin();

$search = sanitize($_GET['q'] ?? '');
$error = '';

// Handle Delete User POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $del_user_id = intval($_POST['user_id']);
    
    // Prevent admin from deleting themselves (safety check)
    if ($del_user_id === $_SESSION['user_id']) {
        $error = 'Anda tidak dapat menghapus akun admin Anda sendiri.';
    } else {
        try {
            // Fetch photo filename to clean up uploads
            $photo_stmt = $pdo->prepare("SELECT foto, name, email FROM users WHERE id = ?");
            $photo_stmt->execute([$del_user_id]);
            $del_user = $photo_stmt->fetch();

            if ($del_user) {
                // Delete profile image file if exists
                if (!empty($del_user['foto']) && file_exists(__DIR__ . '/uploads/' . $del_user['foto'])) {
                    @unlink(__DIR__ . '/uploads/' . $del_user['foto']);
                }

                // Delete user (cascades database relations automatically)
                $del_stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                $del_stmt->execute([$del_user_id]);

                log_activity('User Deleted by Admin', "User {$del_user['name']} ({$del_user['email']}) deleted by Admin ID {$_SESSION['user_id']}.");
                set_flash_message('success', 'Akun mahasiswa ' . htmlspecialchars($del_user['name']) . ' berhasil dihapus.');
                header("Location: admin-users.php");
                exit();
            } else {
                $error = 'Pengguna tidak ditemukan.';
            }
        } catch (PDOException $e) {
            $error = 'Gagal menghapus pengguna: ' . $e->getMessage();
        }
    }
}

// Fetch users list
$users_query = "SELECT * FROM users WHERE role = 'user'";
$params = [];

if (!empty($search)) {
    $users_query .= " AND (name LIKE :q OR email LIKE :q OR jurusan LIKE :q OR universitas LIKE :q)";
    $params['q'] = '%' . $search . '%';
}

$users_query .= " ORDER BY id DESC";

try {
    $stmt = $pdo->prepare($users_query);
    $stmt->execute($params);
    $users_list = $stmt->fetchAll();
} catch (PDOException $e) {
    set_flash_message('error', 'Gagal memuat daftar pengguna.');
    $users_list = [];
}

require_once 'includes/header.php';
?>

<div class="app-container">
    <div class="feed-header animate-fade-in">
        <div class="feed-title-area">
            <h2>Kelola Pengguna (Mahasiswa)</h2>
            <p>Lihat, cari, dan hapus akun mahasiswa yang melanggar ketentuan platform</p>
        </div>
        <a href="admin-dashboard.php" class="btn btn-secondary"><i class="fa-solid fa-gauge"></i> Dashboard</a>
    </div>

    <!-- Search bar -->
    <div class="search-filter-bar animate-fade-in" style="grid-template-columns: 1fr; margin-top: 20px;">
        <form action="admin-users.php" method="GET" style="display: flex; gap: 8px;">
            <input type="text" name="q" class="form-input" placeholder="Cari nama, email, jurusan, atau universitas..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-magnifying-glass"></i> Cari</button>
            <?php if (!empty($search)): ?>
                <a href="admin-users.php" class="btn btn-secondary"><i class="fa-solid fa-rotate-left"></i> Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <?php if (!empty($error)): ?>
        <div class="flash-banner flash-error animate-fade-in">
            <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <!-- User Table -->
    <div class="admin-table-container animate-fade-in" style="animation-delay: 0.1s; margin-top: 20px;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Nama Lengkap</th>
                    <th>Email</th>
                    <th>Jurusan / Universitas</th>
                    <th>Angkatan</th>
                    <th>Tanggal Daftar</th>
                    <th style="text-align: right;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users_list)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--text-secondary); padding: 40px;">Tidak ada pengguna terdaftar yang cocok dengan kriteria.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($users_list as $u): ?>
                        <tr>
                            <td>
                                <a href="profile.php?id=<?php echo $u['id']; ?>" style="font-weight: 600; text-decoration: underline;">
                                    <?php echo htmlspecialchars($u['name']); ?>
                                </a>
                            </td>
                            <td><?php echo htmlspecialchars($u['email']); ?></td>
                            <td>
                                <div><?php echo htmlspecialchars($u['jurusan'] ?? '-'); ?></div>
                                <small style="color: var(--text-secondary);"><?php echo htmlspecialchars($u['universitas'] ?? '-'); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($u['angkatan'] ?? '-'); ?></td>
                            <td><?php echo date('d M Y', strtotime($u['created_at'])); ?></td>
                            <td style="text-align: right;">
                                <form action="admin-users.php" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus akun mahasiswa ini secara permanen? Tindakan ini akan menghapus semua project yang dibuatnya.');" style="display: inline-block;">
                                    <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        <i class="fa-regular fa-trash-can"></i> Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
