# Product Requirements Document (PRD)
## CampusConnect — Platform Kolaborasi SDM Mahasiswa

---

## 1. OVERVIEW

| Item | Detail |
|------|--------|
| **Nama Produk** | CampusConnect |
| **Versi** | 1.0.0 |
| **Tim** | Kelompok 5 |
| **Ketua** | Ahmed Damar Al Kahfi (2409010139) |
| **Anggota** | Nadya Nazwa Priscilla (2409010143), Mawaddah Fadilah (2409010142), Adek Evita Sarah (2409010137), Ofick Surya Adha Z (2409010163) |
| **Tech Stack** | HTML, CSS, JavaScript (Frontend) · PHP (Backend) · MySQL (Database) |
| **Tipe Aplikasi** | Web-based platform |

---

## 2. PROBLEM STATEMENT

Mahasiswa yang memiliki ide project, kemampuan teknis, atau minat tertentu kesulitan menemukan rekan kolaborasi yang sesuai. Tidak adanya platform terpusat menyebabkan:
- Rekrutmen anggota tim dilakukan secara manual (grup WA, mulut ke mulut) → tidak efisien
- Mahasiswa berbakat sulit terekspos ke project yang relevan dengan skill mereka
- Banyak project potensial (PKM, lomba, startup) gagal terbentuk karena kekurangan SDM

---

## 3. GOALS & OBJECTIVES

### Goals
Menjadi platform utama penghubung SDM mahasiswa untuk kegiatan akademik dan non-akademik di lingkungan kampus.

### Objectives
- Mahasiswa dapat menemukan kolaborator berdasarkan skill dan minat dalam waktu singkat
- Pemilik project dapat merekrut anggota tim secara terstruktur dan transparan
- Admin dapat memantau dan mengelola seluruh aktivitas platform

---

## 4. TARGET USERS

| Role | Deskripsi |
|------|-----------|
| **Mahasiswa (User)** | Pengguna utama yang membuat project, mencari project, dan bergabung sebagai anggota tim |
| **Project Owner** | Mahasiswa yang membuat posting project dan mengelola rekrutmen anggota |
| **Admin** | Pengelola platform yang mengawasi konten, pengguna, dan aktivitas sistem |

---

## 5. FITUR UTAMA & SPESIFIKASI FUNGSIONAL

---

### FITUR 1 — Autentikasi (Login & Registrasi)

**Deskripsi:** Sistem akun untuk mengakses platform.

**Acceptance Criteria:**
- User dapat mendaftar menggunakan email dan password
- Sistem memvalidasi format email dan kekuatan password (minimal 8 karakter)
- User menerima konfirmasi setelah registrasi berhasil
- User dapat login menggunakan email & password yang terdaftar
- Sistem menampilkan pesan error yang jelas jika kredensial salah
- Terdapat fitur "Lupa Password" dengan reset via email
- Session login tersimpan dengan mekanisme logout yang aman

**Business Rule:**
- Satu email hanya dapat digunakan untuk satu akun
- Password disimpan dalam bentuk hashed (bcrypt)

---

### FITUR 2 — Profile Mahasiswa

**Deskripsi:** Halaman profil personal yang menampilkan identitas, skill, dan riwayat aktivitas mahasiswa.

**Acceptance Criteria:**
- User dapat mengisi dan mengedit data profil: nama lengkap, jurusan, angkatan, universitas, foto profil, bio singkat
- User dapat menambahkan skill (multi-select/tag, contoh: UI/UX, Python, Public Speaking, Videografi)
- User dapat menambahkan minat/interest (contoh: PKM, Startup, Volunteer, Lomba)
- User dapat menambahkan pengalaman organisasi atau project sebelumnya
- Profil menampilkan daftar project yang pernah dibuat dan diikuti
- Profil dapat dilihat oleh user lain (public profile)

**Business Rule:**
- Foto profil maksimal 2MB, format JPG/PNG
- Skill dipilih dari daftar predefined + opsi custom input
- Profil yang belum dilengkapi menampilkan prompt untuk melengkapi data

---

### FITUR 3 — Posting Project

**Deskripsi:** Fitur untuk membuat dan mengelola posting project kolaborasi.

**Acceptance Criteria:**
- User dapat membuat posting project dengan mengisi:
  - Judul project
  - Kategori (PKM, P2MW, Lomba, Startup, Volunteer, Organisasi, Event Kampus, Lainnya)
  - Deskripsi project
  - Skill yang dibutuhkan (multi-tag)
  - Jumlah anggota yang dicari
  - Deadline pendaftaran
  - Status project (Open / Closed)
  - Kontak/link komunikasi (opsional: WhatsApp group, Discord, dll.)
- Project owner dapat mengedit dan menghapus posting miliknya
- Posting project ditampilkan dalam feed/listing dengan informasi ringkas
- User dapat memfilter project berdasarkan kategori dan skill
- User dapat mencari project menggunakan keyword (search bar)

**Business Rule:**
- Hanya user yang login dapat membuat posting project
- Satu user dapat memiliki lebih dari satu project aktif
- Project dengan deadline yang sudah lewat otomatis berstatus Closed

---

### FITUR 4 — Join Project (Sistem Rekrutmen)

**Deskripsi:** Mekanisme bagi mahasiswa untuk mendaftar dan bergabung ke project yang tersedia.

**Acceptance Criteria:**
- User dapat menekan tombol "Join / Daftar" pada project yang berstatus Open
- User mengisi form pendaftaran singkat (motivasi bergabung, skill relevan yang dimiliki) — opsional per kebijakan owner
- Project owner menerima notifikasi saat ada pendaftar baru
- Project owner dapat melihat daftar pendaftar beserta profil mereka
- Project owner dapat menerima (Approve) atau menolak (Reject) pendaftar
- Pendaftar menerima notifikasi hasil keputusan (diterima/ditolak)
- User tidak dapat mendaftar ke project yang sudah berstatus Closed
- User tidak dapat mendaftar ke project miliknya sendiri

**Business Rule:**
- Satu user hanya bisa mendaftar satu kali ke project yang sama
- Jika kuota anggota sudah terpenuhi, tombol Join otomatis nonaktif

---

### FITUR 5 — Dashboard Admin

**Deskripsi:** Panel administrasi untuk mengelola seluruh data dan aktivitas platform.

**Acceptance Criteria:**
- Admin dapat melihat statistik platform: total user, total project, project aktif, pendaftaran per periode
- Admin dapat melihat, mencari, dan memfilter daftar seluruh pengguna
- Admin dapat menonaktifkan atau menghapus akun pengguna yang melanggar ketentuan
- Admin dapat melihat, mencari, dan memfilter daftar seluruh project
- Admin dapat menghapus posting project yang tidak sesuai
- Admin dapat melihat log aktivitas platform (registrasi baru, project baru, join request)
- Dashboard menampilkan data dalam bentuk tabel dan ringkasan statistik (card/chart sederhana)

**Business Rule:**
- Akses dashboard hanya untuk akun dengan role = admin
- Admin tidak dapat membuat atau join project sebagai user biasa
- Penghapusan akun user otomatis menghapus seluruh posting project miliknya

---

## 6. BUSINESS PROCESS / USER FLOW

```
[Pengguna Baru]
    │
    ▼
Buka Website → Registrasi Akun → Login
    │
    ▼
Lengkapi Profil (Skill, Jurusan, Minat, Pengalaman)
    │
    ├──► [Ingin membuat project]
    │         │
    │         ▼
    │    Buat Posting Project (isi detail, skill dibutuhkan, deadline)
    │         │
    │         ▼
    │    Terima/Tolak Pendaftar → Kelola Tim
    │
    └──► [Ingin bergabung ke project]
              │
              ▼
         Browse/Search Project → Filter by Kategori/Skill
              │
              ▼
         Lihat Detail Project → Klik Join → Isi Form Pendaftaran
              │
              ▼
         Tunggu Notifikasi Keputusan dari Project Owner

[Admin]
    │
    ▼
Login Admin → Dashboard → Kelola User & Project → Pantau Aktivitas
```

---

## 7. NON-FUNCTIONAL REQUIREMENTS

| Aspek | Requirement |
|-------|-------------|
| **Keamanan** | Password di-hash dengan bcrypt; proteksi SQL injection; session management yang aman |
| **Performa** | Halaman utama (feed project) memuat dalam < 3 detik pada koneksi normal |
| **Usability** | Antarmuka responsif (mobile-friendly); navigasi intuitif tanpa perlu panduan |
| **Skalabilitas** | Database dirancang untuk mendukung pertambahan data tanpa restrukturisasi mayor |
| **Validasi** | Semua form input divalidasi di sisi client (JS) dan server (PHP) |
| **Kompatibilitas** | Berjalan di browser modern: Chrome, Firefox, Edge, Safari (versi terbaru) |

---

## 8. DATABASE ENTITIES (Ringkasan)

| Tabel | Kolom Utama |
|-------|-------------|
| `users` | id, name, email, password, jurusan, angkatan, bio, foto, role, created_at |
| `user_skills` | id, user_id, skill_name |
| `projects` | id, owner_id, title, category, description, slots, deadline, status, created_at |
| `project_skills` | id, project_id, skill_name |
| `project_applications` | id, project_id, applicant_id, motivation, status (pending/approved/rejected), applied_at |
| `notifications` | id, user_id, message, is_read, created_at |

---

## 9. PAGES / HALAMAN APLIKASI

| No | Halaman | Akses |
|----|---------|-------|
| 1 | Landing Page | Public |
| 2 | Halaman Registrasi | Public |
| 3 | Halaman Login | Public |
| 4 | Feed / Browse Project | User (Login) |
| 5 | Detail Project | User (Login) |
| 6 | Form Buat Project | User (Login) |
| 7 | Profil User (diri sendiri) | User (Login) |
| 8 | Profil User (orang lain) | User (Login) |
| 9 | Manajemen Project (Owner) | Project Owner |
| 10 | Notifikasi | User (Login) |
| 11 | Dashboard Admin | Admin |
| 12 | Manajemen User (Admin) | Admin |
| 13 | Manajemen Project (Admin) | Admin |

---

## 10. CONSTRAINTS & ASSUMPTIONS

**Constraints:**
- Platform ini hanya untuk mahasiswa (tidak mencakup dosen atau pihak eksternal kampus)
- Tech stack terbatas pada HTML/CSS/JS + PHP + MySQL sesuai kemampuan tim
- Tidak ada fitur chat/messaging real-time pada versi 1.0 (komunikasi difasilitasi via link eksternal)
- Tidak ada sistem pembayaran

**Assumptions:**
- Setiap pengguna mendaftar menggunakan email aktif
- Verifikasi status mahasiswa dilakukan secara honor system (tidak ada integrasi SIAKAD)
- Platform dihosting secara lokal atau shared hosting pada tahap pengembangan

---

## 11. OUT OF SCOPE (Versi 1.0)

- Real-time chat / messaging antar pengguna
- Notifikasi push / email otomatis
- Integrasi dengan sistem akademik kampus (SIAKAD, SSO)
- Fitur rating/review anggota tim
- Mobile app (Android/iOS)
- Fitur rekomendasi project berbasis AI

---

## 12. SUCCESS METRICS

| Metric | Target |
|--------|--------|
| Registrasi user berhasil | 100% success rate tanpa error |
| Pembuatan posting project | Proses selesai dalam < 2 menit |
| Proses join & approval | Notifikasi terkirim dalam < 5 detik setelah aksi |
| Semua fitur utama berjalan | 0 critical bug pada demo akhir |

---

*Dokumen ini dibuat sebagai panduan pengembangan CampusConnect v1.0 oleh Kelompok 5.*
*Last updated: Mei 2026*
