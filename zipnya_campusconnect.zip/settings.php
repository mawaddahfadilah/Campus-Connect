<?php
$page_title = "Pengaturan Akun - CampusConnect";
$meta_description = "Perbarui profil Anda dan kelola keamanan akun di CampusConnect.";
require_once 'includes/functions.php';
require_login();

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';
$active_tab = isset($_GET['tab']) ? sanitize($_GET['tab']) : 'profile';

// Ensure uploads folder exists
if (!file_exists(__DIR__ . '/uploads')) {
    mkdir(__DIR__ . '/uploads', 0777, true);
}

try {
    // Fetch current user details
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!$user) {
        set_flash_message('error', 'Pengguna tidak ditemukan.');
        header("Location: logout.php");
        exit();
    }

    // Fetch current skills
    $skills_stmt = $pdo->prepare("SELECT skill_name FROM user_skills WHERE user_id = ?");
    $skills_stmt->execute([$user_id]);
    $current_skills = $skills_stmt->fetchAll(PDO::FETCH_COLUMN);
    $skills_string = implode(',', $current_skills);

    // Calculate completeness
    $completeness = 0;
    if ($user['role'] !== 'admin') {
        $completeness = 20;
        if (!empty($user['bio'])) $completeness += 20;
        if (!empty($user['jurusan'])) $completeness += 20;
        if (!empty($user['angkatan'])) $completeness += 20;
        if (!empty($current_skills)) $completeness += 20;
    }

} catch (PDOException $e) {
    set_flash_message('error', 'Gagal memuat detail akun.');
    header("Location: index.php");
    exit();
}

// ---------------------------------------------------------
// POST Handlers
// ---------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $name = sanitize($_POST['name'] ?? '');
        $jurusan = sanitize($_POST['jurusan'] ?? '');
        $angkatan = isset($_POST['angkatan']) && $_POST['angkatan'] !== '' ? intval($_POST['angkatan']) : NULL;
        $universitas = sanitize($_POST['universitas'] ?? '');
        $bio = sanitize($_POST['bio'] ?? '');
        $skills_input = sanitize($_POST['skills'] ?? '');

        if (empty($name)) {
            $error = 'Nama Lengkap wajib diisi.';
            $active_tab = 'profile';
        } else {
            try {
                $pdo->beginTransaction();
                $photo_filename = $user['foto'];

                // Handle profile picture upload
                if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] !== UPLOAD_ERR_NO_FILE) {
                    $file = $_FILES['profile_image'];
                    $max_size = 2 * 1024 * 1024; // 2MB
                    $allowed_extensions = ['jpg', 'jpeg', 'png'];
                    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

                    if ($file['error'] !== UPLOAD_ERR_OK) {
                        throw new Exception('Gagal mengunggah foto. Error code: ' . $file['error']);
                    }

                    if (!in_array($file_ext, $allowed_extensions)) {
                        throw new Exception('Format berkas harus JPG, JPEG, atau PNG.');
                    }

                    if ($file['size'] > $max_size) {
                        throw new Exception('Ukuran foto maksimal adalah 2MB.');
                    }

                    // Delete old profile picture if exists
                    if (!empty($user['foto']) && file_exists(__DIR__ . '/uploads/' . $user['foto'])) {
                        @unlink(__DIR__ . '/uploads/' . $user['foto']);
                    }

                    $photo_filename = md5(uniqid(rand(), true)) . '.' . $file_ext;
                    $destination = __DIR__ . '/uploads/' . $photo_filename;

                    if (!move_uploaded_file($file['tmp_name'], $destination)) {
                        throw new Exception('Gagal menyimpan berkas ke server.');
                    }

                    $_SESSION['foto'] = $photo_filename;
                }

                // Update users details
                $up_stmt = $pdo->prepare("UPDATE users SET name = ?, jurusan = ?, angkatan = ?, universitas = ?, bio = ?, foto = ? WHERE id = ?");
                $up_stmt->execute([$name, $jurusan, $angkatan, $universitas, $bio, $photo_filename, $user_id]);

                // Update session
                $_SESSION['name'] = $name;

                // Update skills (re-populate)
                $del_skills = $pdo->prepare("DELETE FROM user_skills WHERE user_id = ?");
                $del_skills->execute([$user_id]);

                if (!empty($skills_input)) {
                    $skills_array = array_unique(array_filter(array_map('trim', explode(',', $skills_input))));
                    $ins_skill = $pdo->prepare("INSERT INTO user_skills (user_id, skill_name) VALUES (?, ?)");
                    foreach ($skills_array as $skill) {
                        if (!empty($skill)) {
                            $ins_skill->execute([$user_id, $skill]);
                        }
                    }
                }

                $pdo->commit();
                log_activity('User Edited Profile', "User $name updated profile details via settings.");
                set_flash_message('success', 'Profil Anda berhasil diperbarui.');
                header("Location: settings.php?tab=profile");
                exit();

            } catch (Exception $e) {
                $pdo->rollBack();
                $error = $e->getMessage();
                $active_tab = 'profile';
            }
        }
    } elseif (isset($_POST['change_password'])) {
        $current_pass = $_POST['current_password'] ?? '';
        $new_pass = $_POST['new_password'] ?? '';
        $confirm_pass = $_POST['confirm_password'] ?? '';

        if (empty($current_pass) || empty($new_pass) || empty($confirm_pass)) {
            $error = 'Semua kolom kata sandi wajib diisi.';
            $active_tab = 'security';
        } elseif (!password_verify($current_pass, $user['password'])) {
            $error = 'Kata sandi saat ini salah.';
            $active_tab = 'security';
        } elseif (!validate_password($new_pass)) {
            $error = 'Kata sandi baru harus minimal 8 karakter.';
            $active_tab = 'security';
        } elseif ($new_pass !== $confirm_pass) {
            $error = 'Konfirmasi kata sandi baru tidak cocok.';
            $active_tab = 'security';
        } else {
            try {
                $hashed_pass = password_hash($new_pass, PASSWORD_DEFAULT);
                $up_stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                $up_stmt->execute([$hashed_pass, $user_id]);

                log_activity('Password Changed', "User changed password via settings.");
                set_flash_message('success', 'Kata sandi Anda berhasil diperbarui.');
                header("Location: settings.php?tab=security");
                exit();
            } catch (PDOException $e) {
                $error = 'Gagal memperbarui kata sandi.';
                $active_tab = 'security';
            }
        }
    } elseif (isset($_POST['add_portfolio'])) {
        $caption = sanitize($_POST['caption'] ?? '');
        
        if (empty($caption)) {
            $error = 'Judul portfolio wajib diisi.';
            $active_tab = 'portfolio';
        } elseif (!isset($_FILES['portfolio_image']) || $_FILES['portfolio_image']['error'] === UPLOAD_ERR_NO_FILE) {
            $error = 'Berkas sertifikat/portfolio wajib diunggah.';
            $active_tab = 'portfolio';
        } else {
            try {
                $file = $_FILES['portfolio_image'];
                $max_size = 2 * 1024 * 1024; // 2MB
                $allowed_extensions = ['jpg', 'jpeg', 'png'];
                $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

                if ($file['error'] !== UPLOAD_ERR_OK) {
                    throw new Exception('Gagal mengunggah berkas. Error code: ' . $file['error']);
                }

                if (!in_array($file_ext, $allowed_extensions)) {
                    throw new Exception('Format berkas harus JPG, JPEG, atau PNG.');
                }

                if ($file['size'] > $max_size) {
                    throw new Exception('Ukuran berkas maksimal adalah 2MB.');
                }

                $filename = 'portfolio_' . md5(uniqid(rand(), true)) . '.' . $file_ext;
                $destination = __DIR__ . '/uploads/' . $filename;

                if (!move_uploaded_file($file['tmp_name'], $destination)) {
                    throw new Exception('Gagal menyimpan berkas ke server.');
                }

                // Insert database record
                $ins_stmt = $pdo->prepare("INSERT INTO user_portfolio (user_id, file_name, caption) VALUES (?, ?, ?)");
                $ins_stmt->execute([$user_id, $filename, $caption]);

                log_activity('User Added Portfolio', "User uploaded a new portfolio item: $caption");
                set_flash_message('success', 'Portfolio berhasil diunggah.');
                header("Location: settings.php?tab=portfolio");
                exit();

            } catch (Exception $e) {
                $error = $e->getMessage();
                $active_tab = 'portfolio';
            }
        }
    } elseif (isset($_POST['delete_portfolio'])) {
        $portfolio_id = intval($_POST['portfolio_id'] ?? 0);

        try {
            // Fetch file name first
            $sel_stmt = $pdo->prepare("SELECT * FROM user_portfolio WHERE id = ? AND user_id = ?");
            $sel_stmt->execute([$portfolio_id, $user_id]);
            $item = $sel_stmt->fetch();

            if ($item) {
                // Delete file
                $filepath = __DIR__ . '/uploads/' . $item['file_name'];
                if (file_exists($filepath)) {
                    @unlink($filepath);
                }

                // Delete DB record
                $del_stmt = $pdo->prepare("DELETE FROM user_portfolio WHERE id = ?");
                $del_stmt->execute([$portfolio_id]);

                log_activity('User Deleted Portfolio', "User deleted portfolio item: " . $item['caption']);
                set_flash_message('success', 'Portfolio berhasil dihapus.');
            } else {
                set_flash_message('error', 'Portfolio tidak ditemukan.');
            }
            header("Location: settings.php?tab=portfolio");
            exit();

        } catch (PDOException $e) {
            $error = 'Gagal menghapus portfolio dari database.';
            $active_tab = 'portfolio';
        }
    }
}

// Generate initials
$initials = '';
if (!empty($user['name'])) {
    $parts = explode(' ', $user['name']);
    $initials = strtoupper(substr($parts[0], 0, 1) . (isset($parts[1]) ? substr($parts[1], 0, 1) : ''));
}

require_once 'includes/header.php';
?>

<div class="app-container">
    <div class="page-header animate-fade-in">
        <div class="page-header-text">
            <h1>Pengaturan Akun</h1>
            <p>Kelola informasi profil pribadi, keahlian, dan kata sandi keamanan Anda.</p>
        </div>
        <a href="profile.php" class="btn btn-secondary" style="flex-shrink:0;"><i class="fa-solid fa-user"></i> Lihat Profil Saya</a>
    </div>

    <?php if (!empty($error)): ?>
        <div class="flash-banner flash-error animate-fade-in" style="margin-top: 20px;">
            <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <div class="settings-layout">
        <!-- Settings Nav Sidebar -->
        <aside class="settings-nav animate-fade-in">
            <a href="#profile" class="settings-nav-item <?php echo $active_tab === 'profile' ? 'active' : ''; ?>" data-target="profile">
                <i class="fa-regular fa-user"></i> Edit Profil
            </a>
            <?php if ($user['role'] !== 'admin'): ?>
            <a href="#portfolio" class="settings-nav-item <?php echo $active_tab === 'portfolio' ? 'active' : ''; ?>" data-target="portfolio">
                <i class="fa-regular fa-file-image"></i> Portfolio & Sertifikat
            </a>
            <?php endif; ?>
            <a href="#security" class="settings-nav-item <?php echo $active_tab === 'security' ? 'active' : ''; ?>" data-target="security">
                <i class="fa-solid fa-lock"></i> Keamanan & Sandi
            </a>
        </aside>

        <!-- Settings Content Panels -->
        <div class="settings-content animate-fade-in" style="animation-delay: 0.05s;">
            <!-- PROFILE PANEL -->
            <div id="panel-profile" class="settings-panel <?php echo $active_tab === 'profile' ? 'active' : ''; ?> card" style="padding: 24px;">
                <h3 style="margin-top: 0; margin-bottom: 8px; font-weight: 700; font-size: 1.25rem;">Informasi Profil</h3>
                <p style="color: var(--color-text-muted); font-size: 0.875rem; margin-bottom: 24px; border-bottom: 1px solid var(--color-border); padding-bottom: 12px;">
                    Perbarui profil personal Anda untuk menarik perhatian pemilik project.
                </p>

                <!-- Profile Completeness -->
                <?php if ($user['role'] !== 'admin'): ?>
                    <div class="completeness-container" style="margin-bottom: 24px; padding: 14px; background: var(--color-bg); border-radius: 8px; border: 1px solid var(--color-border);">
                        <div style="display:flex; justify-content:space-between; font-size:0.875rem; font-weight:600; margin-bottom: 6px;">
                            <span style="color: var(--color-text-secondary);">Kelengkapan Profil</span>
                            <span style="color: var(--color-primary);"><?php echo $completeness; ?>%</span>
                        </div>
                        <div style="height: 6px; background: var(--color-border); border-radius: 10px; overflow: hidden;">
                            <div style="width: <?php echo $completeness; ?>%; height: 100%; background: var(--color-primary); border-radius: 10px;"></div>
                        </div>
                    </div>
                <?php endif; ?>

                <form action="settings.php?tab=profile" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="update_profile" value="1">
                    
                    <!-- Avatar Upload -->
                    <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 24px; flex-wrap: wrap;">
                        <div>
                            <?php if (!empty($user['foto']) && file_exists('uploads/' . $user['foto'])): ?>
                                <img src="uploads/<?php echo htmlspecialchars($user['foto']); ?>" alt="Avatar" id="profile_preview" style="width: 90px; height: 90px; border-radius: 50%; object-fit: cover; border: 2px solid var(--color-border);">
                            <?php else: ?>
                                <div id="avatar_init" style="width: 90px; height: 90px; border-radius: 50%; background: var(--color-primary); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 2.2rem; font-weight: 700;">
                                    <?php echo htmlspecialchars($initials); ?>
                                </div>
                                <img src="" alt="Avatar Preview" id="profile_preview" style="display: none; width: 90px; height: 90px; border-radius: 50%; object-fit: cover; border: 2px solid var(--color-border);">
                            <?php endif; ?>
                        </div>
                        <div>
                            <label class="form-label" style="margin-bottom: 6px;">Foto Profil</label>
                            <input type="file" name="profile_image" id="profile_image_upload" accept="image/png, image/jpeg, image/jpg" style="display: none;">
                            <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('profile_image_upload').click();">
                                <i class="fa-solid fa-upload"></i> Pilih Foto
                            </button>
                            <small style="display: block; margin-top: 6px; font-size: 0.78rem; color: var(--color-text-muted);">Format JPG/PNG, Maks. 2MB</small>
                        </div>
                    </div>

                    <!-- Input Grid -->
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 20px;">
                        <div class="form-group">
                            <label for="name" class="form-label">Nama Lengkap</label>
                            <input type="text" name="name" id="name" class="form-input" required value="<?php echo htmlspecialchars($user['name']); ?>">
                        </div>

                        <div class="form-group">
                            <label for="email" class="form-label">Email Kampus (Akun)</label>
                            <input type="email" id="email" class="form-input" disabled value="<?php echo htmlspecialchars($user['email']); ?>" style="background: var(--color-bg); cursor: not-allowed; color: var(--color-text-muted);">
                        </div>

                        <?php if ($user['role'] !== 'admin'): ?>
                            <div class="form-group">
                                <label for="universitas" class="form-label">Universitas</label>
                                <input type="text" name="universitas" id="universitas" class="form-input" placeholder="Contoh: Universitas Indonesia" value="<?php echo htmlspecialchars($user['universitas'] ?? ''); ?>">
                            </div>

                            <div class="form-group">
                                <label for="jurusan" class="form-label">Jurusan</label>
                                <input type="text" name="jurusan" id="jurusan" class="form-input" placeholder="Contoh: Teknik Informatika" value="<?php echo htmlspecialchars($user['jurusan'] ?? ''); ?>">
                            </div>

                            <div class="form-group">
                                <label for="angkatan" class="form-label">Angkatan</label>
                                <input type="number" name="angkatan" id="angkatan" class="form-input" placeholder="Contoh: 2024" min="2010" max="<?php echo date('Y') + 1; ?>" value="<?php echo htmlspecialchars($user['angkatan'] ?? ''); ?>">
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if ($user['role'] !== 'admin'): ?>
                        <!-- Bio -->
                        <div class="form-group" style="margin-bottom: 20px;">
                            <label for="bio" class="form-label">Bio Singkat</label>
                            <textarea name="bio" id="bio" class="form-input" rows="4" placeholder="Tulis perkenalan singkat mengenai minat dan fokus keahlian Anda..." style="resize: vertical; font-family: inherit;"><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                        </div>

                        <!-- Skills -->
                        <div class="form-group" style="margin-bottom: 20px;">
                            <label class="form-label">Keahlian (Skills)</label>
                            <div class="tags-input-container">
                                <!-- Rendered badges in JS -->
                                <input type="text" id="skill_type_input" placeholder="Ketik keahlian lalu tekan Enter atau Koma">
                            </div>
                            <input type="hidden" name="skills" value="<?php echo htmlspecialchars($skills_string); ?>">
                            <small class="form-help">Tekan Enter atau tanda koma ( , ) untuk menambahkan tag keahlian.</small>
                            
                            <div style="margin-top: 14px;">
                                <div style="font-size: 0.8rem; color: var(--color-text-secondary); margin-bottom: 8px; font-weight: 600;">Rekomendasi Keahlian:</div>
                                <div class="predefined-tags-list">
                                    <button type="button" class="predefined-tag-btn" data-tag="UI/UX">UI/UX</button>
                                    <button type="button" class="predefined-tag-btn" data-tag="Figma">Figma</button>
                                    <button type="button" class="predefined-tag-btn" data-tag="HTML">HTML</button>
                                    <button type="button" class="predefined-tag-btn" data-tag="CSS">CSS</button>
                                    <button type="button" class="predefined-tag-btn" data-tag="JavaScript">JavaScript</button>
                                    <button type="button" class="predefined-tag-btn" data-tag="PHP">PHP</button>
                                    <button type="button" class="predefined-tag-btn" data-tag="Python">Python</button>
                                    <button type="button" class="predefined-tag-btn" data-tag="Marketing">Marketing</button>
                                    <button type="button" class="predefined-tag-btn" data-tag="Copywriting">Copywriting</button>
                                    <button type="button" class="predefined-tag-btn" data-tag="Product Management">Product Management</button>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div style="display: flex; justify-content: flex-end; gap: 14px; border-top: 1px solid var(--color-border); padding-top: 18px; margin-top: 30px;">
                        <button type="submit" class="btn btn-primary">Simpan Profil</button>
                    </div>
                </form>
            </div>

            <!-- SECURITY PANEL -->
            <div id="panel-security" class="settings-panel <?php echo $active_tab === 'security' ? 'active' : ''; ?> card" style="padding: 24px;">
                <h3 style="margin-top: 0; margin-bottom: 8px; font-weight: 700; font-size: 1.25rem;">Keamanan & Sandi</h3>
                <p style="color: var(--color-text-muted); font-size: 0.875rem; margin-bottom: 24px; border-bottom: 1px solid var(--color-border); padding-bottom: 12px;">
                    Perbarui kata sandi akun Anda untuk meningkatkan perlindungan.
                </p>

                <form action="settings.php?tab=security" method="POST">
                    <input type="hidden" name="change_password" value="1">

                    <div class="form-group" style="margin-bottom: 18px; max-width: 500px;">
                        <label for="current_password" class="form-label">Kata Sandi Saat Ini</label>
                        <input type="password" name="current_password" id="current_password" class="form-input" required>
                    </div>

                    <div class="form-group" style="margin-bottom: 18px; max-width: 500px;">
                        <label for="new_password" class="form-label">Kata Sandi Baru</label>
                        <input type="password" name="new_password" id="new_password" class="form-input" required placeholder="Minimal 8 karakter">
                    </div>

                    <div class="form-group" style="margin-bottom: 24px; max-width: 500px;">
                        <label for="confirm_password" class="form-label">Konfirmasi Kata Sandi Baru</label>
                        <input type="password" name="confirm_password" id="confirm_password" class="form-input" required>
                    </div>

                    <div style="display: flex; justify-content: flex-end; gap: 14px; border-top: 1px solid var(--color-border); padding-top: 18px; margin-top: 30px;">
                        <button type="submit" class="btn btn-primary">Ubah Kata Sandi</button>
                    </div>
                </form>
            </div>

            <?php if ($user['role'] !== 'admin'):
                // Fetch portfolio items for display
                $pf_items = [];
                try {
                    $pf_stmt = $pdo->prepare("SELECT * FROM user_portfolio WHERE user_id = ? ORDER BY id DESC");
                    $pf_stmt->execute([$user_id]);
                    $pf_items = $pf_stmt->fetchAll();
                } catch (PDOException $e) { /* fail silently */ }
            ?>
            <!-- PORTFOLIO PANEL -->
            <div id="panel-portfolio" class="settings-panel <?php echo $active_tab === 'portfolio' ? 'active' : ''; ?> card" style="padding: 24px;">
                <h3 style="margin-top: 0; margin-bottom: 8px; font-weight: 700; font-size: 1.25rem;">Portfolio & Sertifikat</h3>
                <p style="color: var(--color-text-muted); font-size: 0.875rem; margin-bottom: 24px; border-bottom: 1px solid var(--color-border); padding-bottom: 12px;">
                    Unggah foto sertifikat, penghargaan, atau karya untuk memperkuat profil lamaran project Anda.
                </p>

                <!-- Upload Form -->
                <form action="settings.php?tab=portfolio" method="POST" enctype="multipart/form-data" style="margin-bottom: 32px;">
                    <input type="hidden" name="add_portfolio" value="1">

                    <!-- Upload Zone -->
                    <div id="portfolio_upload_zone" class="portfolio-upload-zone" onclick="document.getElementById('portfolio_image_input').click();">
                        <i class="fa-solid fa-cloud-arrow-up" style="font-size: 2rem; color: var(--color-primary); margin-bottom: 10px;"></i>
                        <p class="upload-zone-text">Klik atau seret gambar ke sini</p>
                        <p class="upload-zone-sub">Format JPG atau PNG, Maks. 2MB</p>
                    </div>

                    <input type="file" id="portfolio_image_input" name="portfolio_image" accept="image/jpg,image/jpeg,image/png" style="display:none;">

                    <!-- Preview Container (hidden initially) -->
                    <div id="portfolio_image_preview_container" style="display:none; margin-top: 14px; position:relative; width:fit-content;">
                        <img id="portfolio_image_preview" src="" alt="Preview" style="max-width: 280px; max-height: 200px; border-radius: 8px; border: 1px solid var(--color-border); display:block;">
                        <button type="button" id="remove_portfolio_preview_btn" class="btn btn-secondary btn-sm" style="margin-top:8px;">
                            <i class="fa-solid fa-xmark"></i> Ganti Gambar
                        </button>
                    </div>

                    <!-- Caption -->
                    <div class="form-group" style="margin-top: 16px; max-width: 500px;">
                        <label for="portfolio_caption" class="form-label">Judul / Keterangan</label>
                        <input type="text" name="caption" id="portfolio_caption" class="form-input" placeholder="Contoh: Sertifikat UI/UX Google, Juara 2 PKM 2024" required>
                    </div>

                    <div style="margin-top: 16px;">
                        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-upload"></i> Unggah Portfolio</button>
                    </div>
                </form>

                <!-- Uploaded Items List -->
                <?php if (!empty($pf_items)): ?>
                    <h4 style="font-family: var(--font-heading); font-weight: 700; font-size: 1rem; margin-bottom: 14px; color: var(--color-text-primary);">
                        Portfolio Diunggah (<?php echo count($pf_items); ?>)
                    </h4>
                    <div class="portfolio-grid">
                        <?php foreach ($pf_items as $item): ?>
                            <div class="card portfolio-card">
                                <div class="portfolio-img-wrapper">
                                    <img src="uploads/<?php echo htmlspecialchars($item['file_name']); ?>" alt="<?php echo htmlspecialchars($item['caption']); ?>" class="portfolio-img">
                                </div>
                                <div class="portfolio-info">
                                    <p class="portfolio-caption"><?php echo htmlspecialchars($item['caption']); ?></p>
                                    <span class="portfolio-date"><?php echo date('d M Y', strtotime($item['uploaded_at'])); ?></span>
                                    <form method="POST" action="settings.php?tab=portfolio" style="margin-top: 8px;" onsubmit="return confirm('Hapus portfolio ini?');">
                                        <input type="hidden" name="delete_portfolio" value="1">
                                        <input type="hidden" name="portfolio_id" value="<?php echo $item['id']; ?>">
                                        <button type="submit" class="btn btn-secondary btn-sm" style="color: var(--color-red); border-color: var(--color-red);">
                                            <i class="fa-solid fa-trash"></i> Hapus
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state" style="padding: 40px 20px;">
                        <div class="empty-state-icon"><i class="fa-regular fa-file-image"></i></div>
                        <div class="empty-state-title">Belum ada portfolio</div>
                        <p class="empty-state-desc">Unggah sertifikat atau karya Anda untuk menarik perhatian pemilik project.</p>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.settings-layout {
    display: grid;
    grid-template-columns: 240px 1fr;
    gap: 30px;
    margin-top: 24px;
    align-items: start;
}
@media (max-width: 768px) {
    .settings-layout {
        grid-template-columns: 1fr;
        gap: 16px;
    }
    .settings-nav {
        flex-direction: row;
        flex-wrap: nowrap;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        padding: 8px;
        gap: 4px;
        scroll-snap-type: x mandatory;
    }
    .settings-nav-item {
        scroll-snap-align: start;
        flex-shrink: 0;
        white-space: nowrap;
        padding: 9px 16px;
    }
}
.settings-nav {
    display: flex;
    flex-direction: column;
    gap: 6px;
    background: var(--color-bg);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    padding: 12px;
}
.settings-nav-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 14px;
    border-radius: 6px;
    color: var(--color-text-secondary);
    text-decoration: none;
    font-size: 0.9rem;
    font-weight: 500;
    transition: all 0.2s ease;
    border: none;
    background: transparent;
    text-align: left;
    cursor: pointer;
}
.settings-nav-item:hover {
    color: var(--color-primary);
    background: var(--color-surface);
}
.settings-nav-item.active {
    color: var(--color-primary);
    background: var(--color-primary-light);
    font-weight: 600;
}
.settings-panel {
    display: none;
}
.settings-panel.active {
    display: block;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // ---------------------------------------------------------
    // Settings Tab Switching JS
    // ---------------------------------------------------------
    const navItems = document.querySelectorAll('.settings-nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('data-target');
            
            // Toggle active nav class
            navItems.forEach(i => i.classList.remove('active'));
            this.classList.add('active');
            
            // Toggle panels
            document.querySelectorAll('.settings-panel').forEach(panel => {
                panel.classList.remove('active');
            });
            const activePanel = document.getElementById('panel-' + target);
            if (activePanel) activePanel.classList.add('active');
            
            // Update URL query tab parameter without reloading
            window.history.pushState(null, null, 'settings.php?tab=' + target);
        });
    });

    // ---------------------------------------------------------
    // Image Upload Preview JS
    // ---------------------------------------------------------
    const fileInput = document.getElementById('profile_image_upload');
    const imgPreview = document.getElementById('profile_preview');
    const initialAvatar = document.getElementById('avatar_init');

    if (fileInput) {
        fileInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    if (imgPreview) {
                        imgPreview.src = e.target.result;
                        imgPreview.style.display = 'block';
                        if (initialAvatar) {
                            initialAvatar.style.display = 'none';
                        }
                    }
                }
                reader.readAsDataURL(file);
            }
        });
    }

    // ---------------------------------------------------------
    // Portfolio Upload Preview JS
    // ---------------------------------------------------------
    const pfInput = document.getElementById('portfolio_image_input');
    const pfPreviewContainer = document.getElementById('portfolio_image_preview_container');
    const pfPreview = document.getElementById('portfolio_image_preview');
    const pfRemoveBtn = document.getElementById('remove_portfolio_preview_btn');
    const pfUploadZone = document.getElementById('portfolio_upload_zone');

    if (pfInput && pfPreviewContainer && pfPreview) {
        pfInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    pfPreview.src = e.target.result;
                    pfPreviewContainer.style.display = 'block';
                    if (pfUploadZone) pfUploadZone.style.display = 'none';
                }
                reader.readAsDataURL(file);
            }
        });

        if (pfRemoveBtn) {
            pfRemoveBtn.addEventListener('click', function() {
                pfInput.value = '';
                pfPreview.src = '';
                pfPreviewContainer.style.display = 'none';
                if (pfUploadZone) pfUploadZone.style.display = 'flex';
            });
        }
    }

    // ---------------------------------------------------------
    // Tags Input System for Skills (Matches profile-edit.php)
    // ---------------------------------------------------------
    const skillsHiddenInput = document.querySelector('input[name="skills"]');
    const tagsContainer = document.querySelector('.tags-input-container');
    const skillInput = document.getElementById('skill_type_input');

    if (skillsHiddenInput && tagsContainer && skillInput) {
        let skillsArray = skillsHiddenInput.value ? skillsHiddenInput.value.split(',').map(s => s.trim()).filter(s => s) : [];

        function renderTags() {
            // Remove existing badges
            tagsContainer.querySelectorAll('.tag-badge').forEach(b => b.remove());

            // Render all skills
            skillsArray.forEach((skill, idx) => {
                const badge = document.createElement('span');
                badge.className = 'tag-badge';
                badge.innerHTML = `${skill} <i class="fa-solid fa-xmark remove-tag remove-tag-btn" data-index="${idx}"></i>`;
                tagsContainer.insertBefore(badge, skillInput);
            });

            // Update hidden input value
            skillsHiddenInput.value = skillsArray.join(',');
        }

        function addTag(tag) {
            tag = tag.trim();
            if (tag && !skillsArray.includes(tag)) {
                skillsArray.push(tag);
                renderTags();
            }
            skillInput.value = '';
        }

        // Add tag on Enter or Comma
        skillInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                addTag(this.value);
            }
        });

        skillInput.addEventListener('input', function() {
            if (this.value.endsWith(',')) {
                addTag(this.value.slice(0, -1));
            }
        });

        // Remove tag action
        tagsContainer.addEventListener('click', function(e) {
            if (e.target.classList.contains('remove-tag-btn')) {
                const idx = parseInt(e.target.getAttribute('data-index'));
                skillsArray.splice(idx, 1);
                renderTags();
            }
        });

        // Predefined suggestions action
        document.querySelectorAll('.predefined-tag-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const tag = this.getAttribute('data-tag');
                addTag(tag);
            });
        });

        // Initialize tags rendering
        renderTags();
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
