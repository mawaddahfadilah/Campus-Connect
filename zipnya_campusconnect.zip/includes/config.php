<?php
// Session configuration
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Database Credentials (DIUBAH UNTUK INFINITYFREE)
define('DB_HOST', 'sql301.infinityfree.com'); 
define('DB_USER', 'if0_42129755');            
define('DB_PASS', 'Q9nYcXnoEe79');
define('DB_NAME', 'if0_42129755_schema');     

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    // Jika koneksi gagal, tampilan akan menjadi halaman error bawaan
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Database Connection Error - CampusConnect</title>
        <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
        <style>
            body {
                background: radial-gradient(circle at 50% 50%, #1a1b36 0%, #0d0e1b 100%);
                color: #e2e8f0;
                font-family: 'Outfit', sans-serif;
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
                margin: 0;
                padding: 20px;
                box-sizing: border-box;
            }
            .error-card {
                background: rgba(255, 255, 255, 0.05);
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 16px;
                padding: 40px;
                max-width: 600px;
                width: 100%;
                text-align: center;
                box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
            }
            h1 {
                color: #f56565;
                font-size: 2.2rem;
                margin-top: 0;
                font-weight: 800;
            }
            p {
                color: #a0aec0;
                line-height: 1.6;
                font-size: 1.1rem;
            }
            .instructions {
                text-align: left;
                background: rgba(0, 0, 0, 0.2);
                padding: 20px;
                border-radius: 8px;
                margin-top: 20px;
                font-family: monospace;
                font-size: 0.95rem;
                border-left: 4px solid #3182ce;
                overflow-x: auto;
            }
            .btn {
                display: inline-block;
                margin-top: 25px;
                background: linear-gradient(135deg, #4f46e5 0%, #3b82f6 100%);
                color: #fff;
                padding: 12px 24px;
                text-decoration: none;
                border-radius: 8px;
                font-weight: 600;
                transition: transform 0.2s, box-shadow 0.2s;
            }
            .btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
            }
        </style>
    </head>
    <body>
        <div class="error-card">
            <h1>Koneksi Database Gagal</h1>
            <p>CampusConnect tidak dapat terhubung ke database online InfinityFree. Periksa kembali Host, Username, dan Password di file konfigurasi Anda.</p>
            
            <div class="instructions">
                <strong>Detail Error Teknis:</strong><br>
                <?php echo htmlspecialchars($e->getMessage()); ?>
            </div>
            
            <a href="" class="btn">Coba Lagi</a>
        </div>
    </body>
    </html>
    <?php
    exit();
}
?>