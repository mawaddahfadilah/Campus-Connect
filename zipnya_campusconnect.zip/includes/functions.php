<?php
require_once __DIR__ . '/config.php';

/**
 * Sanitize user input
 */
function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Validate email format
 */
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Validate password strength (minimum 8 characters)
 */
function validate_password($password) {
    return strlen($password) >= 8;
}

/**
 * Check if user is logged in
 */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/**
 * Check if logged in user is admin
 */
function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

/**
 * Enforce login authentication
 */
function require_login() {
    if (!is_logged_in()) {
        header("Location: login.php");
        exit();
    }
}

/**
 * Enforce admin authorization
 */
function require_admin() {
    require_login();
    if (!is_admin()) {
        header("Location: feed.php");
        exit();
    }
}

/**
 * Log action into activity_logs
 */
function log_activity($action, $details = '') {
    global $pdo;
    try {
        $stmt = $pdo->prepare("INSERT INTO activity_logs (action, details) VALUES (?, ?)");
        $stmt->execute([$action, $details]);
    } catch (PDOException $e) {
        // Fail silently or handle
    }
}

/**
 * Add user notification
 */
function add_notification($user_id, $message) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
        $stmt->execute([$user_id, $message]);
    } catch (PDOException $e) {
        // Fail silently
    }
}

/**
 * Get count of unread notifications
 */
function get_unread_notifications_count($user_id) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$user_id]);
        return $stmt->fetchColumn();
    } catch (PDOException $e) {
        return 0;
    }
}

/**
 * Check projects whose deadline has passed and mark them as Closed
 */
function check_overdue_projects() {
    global $pdo;
    try {
        // Update projects to Closed if deadline < current date and status is Open
        $current_date = date('Y-m-d');
        $stmt = $pdo->prepare("UPDATE projects SET status = 'Closed' WHERE deadline < ? AND status = 'Open'");
        $stmt->execute([$current_date]);
    } catch (PDOException $e) {
        // Fail silently
    }
}

/**
 * Flash message helper for feedback alert banners
 */
function set_flash_message($type, $message) {
    $_SESSION['flash_message'] = [
        'type' => $type, // 'success', 'error', 'info', 'warning'
        'text' => $message
    ];
}

function display_flash_message() {
    if (isset($_SESSION['flash_message'])) {
        $msg = $_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        
        $class = '';
        if ($msg['type'] === 'success') $class = 'flash-success';
        if ($msg['type'] === 'error') $class = 'flash-error';
        if ($msg['type'] === 'info') $class = 'flash-info';
        if ($msg['type'] === 'warning') $class = 'flash-warning';
        
        return "<div class='flash-banner {$class}'>{$msg['text']}</div>";
    }
    return '';
}
?>
