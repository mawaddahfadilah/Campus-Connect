<?php
require_once __DIR__ . '/functions.php';
$current_page = basename($_SERVER['PHP_SELF']);
check_overdue_projects();

$is_logged = is_logged_in();
$user_name = $is_logged ? $_SESSION['name'] : '';
$user_email = $is_logged && isset($_SESSION['email']) ? $_SESSION['email'] : '';
$user_role = $is_logged ? $_SESSION['role'] : 'user';
$user_avatar = $is_logged && isset($_SESSION['foto']) ? $_SESSION['foto'] : '';
$initials = '';
if ($is_logged && !empty($user_name)) {
    $parts = explode(' ', $user_name);
    $initials = strtoupper(substr($parts[0], 0, 1) . (isset($parts[1]) ? substr($parts[1], 0, 1) : ''));
}

$unread_notifications = 0;
if ($is_logged) {
    $unread_notifications = get_unread_notifications_count($_SESSION['user_id']);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="CampusConnect — Platform kolaborasi mahasiswa untuk menemukan dan bergabung dalam proyek PKM, startup, lomba, dan kegiatan kampus.">
    <title>CampusConnect — Kolaborasi Mahasiswa</title>

    <!-- Google Fonts: Sora + DM Sans -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&display=swap" rel="stylesheet">

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <!-- Design System CSS -->
    <link rel="stylesheet" href="assets/css/style.css?v=2.4">
</head>
<body>

<header>
    <div class="nav-container">
        <!-- Logo -->
        <a href="index.php" class="logo">
            <span class="logo-campus">Campus</span><span class="logo-connect">Connect</span>
        </a>

        <!-- Nav Links -->
        <nav>
            <ul class="nav-links">
                <?php if ($user_role === 'admin'): ?>
                    <li><a href="admin-dashboard.php" class="nav-link <?php echo ($current_page == 'admin-dashboard.php') ? 'active' : ''; ?>"><i class="fa-solid fa-chart-pie"></i> Dashboard</a></li>
                    <li><a href="admin-users.php" class="nav-link <?php echo ($current_page == 'admin-users.php') ? 'active' : ''; ?>"><i class="fa-solid fa-users"></i> Kelola User</a></li>
                    <li><a href="admin-projects.php" class="nav-link <?php echo ($current_page == 'admin-projects.php') ? 'active' : ''; ?>"><i class="fa-solid fa-folder-open"></i> Kelola Project</a></li>
                <?php else: ?>
                    <li><a href="index.php" class="nav-link <?php echo ($current_page == 'index.php') ? 'active' : ''; ?>">Home</a></li>
                    <li><a href="feed.php" class="nav-link <?php echo ($current_page == 'feed.php') ? 'active' : ''; ?>">Cari Project</a></li>
                    <?php if ($is_logged): ?>
                        <li><a href="project-create.php" class="nav-link <?php echo ($current_page == 'project-create.php') ? 'active' : ''; ?>">Buat Project</a></li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
        </nav>

        <!-- Right Side Controls -->
        <div class="nav-auth">
            <!-- Theme Toggle Button -->
            <button id="theme-toggle" class="theme-toggle-btn" title="Ganti Mode Gelap" aria-label="Toggle Dark Mode">
                <i class="fa-regular fa-moon"></i>
            </button>
            
            <?php if ($is_logged): ?>
                <!-- Notification Bell -->
                <a href="notifications.php" class="notification-bell" title="Notifikasi">
                    <i class="fa-regular fa-bell"></i>
                    <?php if ($unread_notifications > 0): ?>
                        <span class="notification-badge"><?php echo min($unread_notifications, 9); ?></span>
                    <?php endif; ?>
                </a>

                <!-- Profile Dropdown (Desktop) -->
                <div class="nav-profile-wrapper">
                    <div class="nav-profile-trigger">
                        <?php if (!empty($user_avatar) && file_exists('uploads/' . $user_avatar)): ?>
                            <img src="uploads/<?php echo htmlspecialchars($user_avatar); ?>" alt="" class="user-avatar-small">
                        <?php else: ?>
                            <div class="avatar-placeholder"><?php echo htmlspecialchars($initials); ?></div>
                        <?php endif; ?>
                        <i class="fa-solid fa-chevron-down nav-profile-caret"></i>
                    </div>

                    <div class="profile-dropdown">
                        <div class="dropdown-header">
                            <span class="dropdown-name"><?php echo htmlspecialchars($user_name); ?></span>
                            <span class="dropdown-email"><?php echo htmlspecialchars($user_email); ?></span>
                        </div>

                        <a href="profile.php" class="dropdown-item">
                            <i class="fa-regular fa-user"></i> Profil Saya
                        </a>
                        <?php if ($user_role !== 'admin'): ?>
                        <a href="bookmarks.php" class="dropdown-item">
                            <i class="fa-regular fa-bookmark"></i> Bookmark
                        </a>
                        <a href="my-applications.php" class="dropdown-item">
                            <i class="fa-regular fa-paper-plane"></i> Lamaran Saya
                        </a>
                        <?php endif; ?>
                        <a href="settings.php" class="dropdown-item">
                            <i class="fa-regular fa-gear"></i> Pengaturan
                        </a>

                        <div class="dropdown-divider"></div>

                        <a href="logout.php" class="dropdown-item danger">
                            <i class="fa-solid fa-right-from-bracket"></i> Keluar
                        </a>
                    </div>
                </div>

                <!-- Hamburger (Mobile Only) -->
                <button class="nav-hamburger" id="nav-hamburger-btn" aria-label="Buka Menu">
                    <span></span><span></span><span></span>
                </button>

            <?php else: ?>
                <a href="login.php" class="nav-link <?php echo ($current_page == 'login.php') ? 'active' : ''; ?>">Masuk</a>
                <a href="register.php" class="btn btn-primary btn-sm nav-link-btn">Daftar Sekarang</a>
            <?php endif; ?>
        </div>
    </div>
</header>

<?php if ($is_logged): ?>
<!-- Mobile Navigation Drawer -->
<div class="mobile-nav-drawer" id="mobile-nav-drawer">
    <div class="mobile-nav-overlay" id="mobile-nav-overlay"></div>
    <div class="mobile-nav-panel">
        <div class="mobile-nav-header">
            <a href="index.php" class="logo">
                <span class="logo-campus">Campus</span><span class="logo-connect">Connect</span>
            </a>
            <button class="mobile-nav-close" id="mobile-nav-close-btn">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <!-- User Info -->
        <div class="mobile-nav-user">
            <?php if (!empty($user_avatar) && file_exists('uploads/' . $user_avatar)): ?>
                <img src="uploads/<?php echo htmlspecialchars($user_avatar); ?>" alt="" class="user-avatar-small">
            <?php else: ?>
                <div class="avatar-placeholder"><?php echo htmlspecialchars($initials); ?></div>
            <?php endif; ?>
            <div>
                <div class="mobile-nav-user-name"><?php echo htmlspecialchars($user_name); ?></div>
                <div class="mobile-nav-user-role"><?php echo $user_role === 'admin' ? 'Administrator' : 'Mahasiswa'; ?></div>
            </div>
        </div>

        <ul class="mobile-nav-links">
            <?php if ($user_role === 'admin'): ?>
                <li><a href="admin-dashboard.php" class="<?php echo ($current_page == 'admin-dashboard.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-chart-pie"></i> Dashboard
                </a></li>
                <li><a href="admin-users.php" class="<?php echo ($current_page == 'admin-users.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-users"></i> Kelola User
                </a></li>
                <li><a href="admin-projects.php" class="<?php echo ($current_page == 'admin-projects.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-folder-open"></i> Kelola Project
                </a></li>
            <?php else: ?>
                <li><a href="index.php" class="<?php echo ($current_page == 'index.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-house"></i> Home
                </a></li>
                <li><a href="feed.php" class="<?php echo ($current_page == 'feed.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-compass"></i> Cari Project
                </a></li>
                <li><a href="project-create.php" class="<?php echo ($current_page == 'project-create.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-plus"></i> Buat Project
                </a></li>
            <?php endif; ?>

            <li><div class="mobile-nav-divider"></div></li>

            <li><a href="profile.php" class="<?php echo ($current_page == 'profile.php') ? 'active' : ''; ?>">
                <i class="fa-regular fa-user"></i> Profil Saya
            </a></li>
            <?php if ($user_role !== 'admin'): ?>
            <li><a href="bookmarks.php" class="<?php echo ($current_page == 'bookmarks.php') ? 'active' : ''; ?>">
                <i class="fa-regular fa-bookmark"></i> Bookmark
                <?php if ($unread_notifications > 0): ?>
                    <span class="notification-badge" style="position:static; margin-left: auto;"><?php echo min($unread_notifications,9); ?></span>
                <?php endif; ?>
            </a></li>
            <li><a href="my-applications.php" class="<?php echo ($current_page == 'my-applications.php') ? 'active' : ''; ?>">
                <i class="fa-regular fa-paper-plane"></i> Lamaran Saya
            </a></li>
            <?php endif; ?>
            <li><a href="settings.php" class="<?php echo ($current_page == 'settings.php') ? 'active' : ''; ?>">
                <i class="fa-regular fa-gear"></i> Pengaturan
            </a></li>

            <li><div class="mobile-nav-divider"></div></li>

            <li><a href="logout.php" class="danger">
                <i class="fa-solid fa-right-from-bracket"></i> Keluar
            </a></li>
        </ul>
    </div>
</div>
<?php endif; ?>

<div class="page-wrapper">
<?php
echo display_flash_message();
?>
