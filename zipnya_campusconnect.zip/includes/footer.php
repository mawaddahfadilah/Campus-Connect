</div><!-- /.page-wrapper -->

<footer>
    <strong>CampusConnect</strong> — Platform Kolaborasi Mahasiswa &copy; <?php echo date('Y'); ?>
    &nbsp;·&nbsp; Dibuat untuk lingkungan kampus Indonesia
</footer>

<script src="assets/js/main.js?v=2.3"></script>
</body>
</html>
