<?php
require_once 'includes/functions.php';

if (is_logged_in()) { header("Location: feed.php"); exit(); }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name             = sanitize($_POST['name']             ?? '');
    $email            = sanitize($_POST['email']            ?? '');
    $password         = $_POST['password']         ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = 'Semua field wajib diisi.';
    } elseif (!validate_email($email)) {
        $error = 'Format email tidak valid.';
    } elseif (!validate_password($password)) {
        $error = 'Password harus minimal 8 karakter.';
    } elseif ($password !== $confirm_password) {
        $error = 'Konfirmasi password tidak cocok.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = 'Email ini sudah terdaftar.';
            } else {
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $stmt   = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'user')");
                $stmt->execute([$name, $email, $hashed]);
                log_activity('User Registered', "User $name ($email) registered.");
                set_flash_message('success', 'Registrasi berhasil! Silakan masuk.');
                header("Location: login.php");
                exit();
            }
        } catch (PDOException $e) {
            $error = 'Terjadi kesalahan sistem.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Daftar di CampusConnect — platform kolaborasi mahasiswa.">
    <title>Daftar Akun — CampusConnect</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css?v=2.3">
</head>
<body>

<div class="auth-page-wrapper">
    <div class="auth-container animate-fade-in">

        <!-- Logo -->
        <div class="auth-logo">
            <a href="index.php" class="logo" style="justify-content:center; font-size:1.5rem;">
                <span class="logo-campus">Campus</span><span class="logo-connect">Connect</span>
            </a>
        </div>

        <div class="auth-card">
            <h1 class="auth-title">Buat Akun Baru</h1>
            <p class="auth-subtitle">Bergabung dan mulai wujudkan project kampus terbaikmu</p>

            <?php if (!empty($error)): ?>
                <div class="flash-banner flash-error">
                    <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form action="register.php" method="POST">
                <div class="form-group">
                    <label for="name" class="form-label">Nama Lengkap</label>
                    <input type="text" name="name" id="name" class="form-input"
                           placeholder="Contoh: Budi Santoso" required
                           value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>">
                </div>

                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" name="email" id="email" class="form-input"
                           placeholder="nama@student.kampus.ac.id" required
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                    <span class="form-help">Gunakan email aktif milik Anda.</span>
                </div>

                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="password" id="password" class="form-input"
                           placeholder="Minimal 8 karakter" required>
                </div>

                <div class="form-group">
                    <label for="confirm_password" class="form-label">Konfirmasi Password</label>
                    <input type="password" name="confirm_password" id="confirm_password" class="form-input"
                           placeholder="Ulangi password Anda" required>
                </div>

                <button type="submit" class="btn btn-primary" style="width:100%; margin-top:8px; padding:12px;">
                    Daftar Sekarang
                </button>
            </form>
        </div>

        <div class="auth-footer">
            Sudah punya akun? <a href="login.php" class="auth-link">Masuk di sini</a>
        </div>
    </div>
</div>

</body>
</html>
