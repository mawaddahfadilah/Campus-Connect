<?php
// 1. Pengaturan detail database InfinityFree
$host     = "sql301.infinityfree.com"; 
$username = "if0_42129755";            
$password = "Q9nYcXnoEe79";
$database = "if0_42129755_schema";     

// 2. Perintah untuk membuat koneksi ke MySQL
$conn = mysqli_connect($host, $username, $password, $database);

// 3. Cek apakah koneksi berhasil atau gagal
if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}
?>