<?php
$page_title = "Project Disimpan - CampusConnect";
$meta_description = "Lihat daftar project kolaborasi yang Anda simpan.";
require_once 'includes/functions.php';
require_login();

if (is_admin()) {
    header("Location: admin-dashboard.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$bookmarks = [];

try {
    $stmt = $pdo->prepare("SELECT p.*, u.name as owner_name, u.foto as owner_foto
                           FROM projects p
                           JOIN project_bookmarks pb ON p.id = pb.project_id
                           JOIN users u ON p.owner_id = u.id
                           WHERE pb.user_id = ? 
                           ORDER BY pb.created_at DESC");
    $stmt->execute([$user_id]);
    $bookmarks = $stmt->fetchAll();
} catch (PDOException $e) {
    set_flash_message('error', 'Gagal memuat daftar project disimpan: ' . $e->getMessage());
}

require_once 'includes/header.php';
?>

<div class="app-container">
    <!-- Page Header -->
    <div class="page-header animate-fade-in">
        <div class="page-header-text">
            <h1>Project Disimpan</h1>
            <p>Daftar project kolaborasi akademik dan non-akademik yang telah Anda simpan.</p>
        </div>
        <a href="feed.php" class="btn btn-secondary" style="flex-shrink:0;">
            <i class="fa-solid fa-compass"></i> Cari Project
        </a>
    </div>

    <!-- Project List -->
    <div class="animate-fade-in" style="margin-top: 24px;">
        <?php if (empty($bookmarks)): ?>
            <div class="empty-state card">
                <div class="empty-state-icon"><i class="fa-regular fa-bookmark"></i></div>
                <div class="empty-state-title">Belum ada project disimpan</div>
                <p class="empty-state-desc">Jelajahi project menarik dari feed dan klik ikon simpan untuk mengaksesnya cepat di sini.</p>
                <a href="feed.php" class="btn btn-primary">Cari Project</a>
            </div>
        <?php else: ?>
            <div class="project-grid">
                <?php foreach ($bookmarks as $project):
                    $p_skills = [];
                    try {
                        $ps_stmt = $pdo->prepare("SELECT skill_name FROM project_skills WHERE project_id = ?");
                        $ps_stmt->execute([$project['id']]);
                        $p_skills = $ps_stmt->fetchAll(PDO::FETCH_COLUMN);
                    } catch (Exception $e) {}

                    $cat_lower = strtolower($project['category']);
                    $badge_cls = 'badge-lainnya';
                    $cat_map   = ['pkm'=>'pkm','p2mw'=>'p2mw','lomba'=>'lomba','startup'=>'startup','volunteer'=>'volunteer','organisasi'=>'organisasi','event kampus'=>'event'];
                    if (isset($cat_map[$cat_lower])) $badge_cls = 'badge-' . $cat_map[$cat_lower];

                    $status_badge = ($project['status'] === 'Open') ? 'badge-open' : 'badge-closed';
                    
                    $p_parts = explode(' ', $project['owner_name']);
                    $p_init  = strtoupper(substr($p_parts[0],0,1).(isset($p_parts[1])?substr($p_parts[1],0,1):''));
                ?>
                <a href="project-detail.php?id=<?php echo $project['id']; ?>" class="project-card animate-fade-in">
                    <div class="project-card-top">
                        <div class="project-card-badges">
                            <span class="badge <?php echo $badge_cls; ?>"><?php echo htmlspecialchars($project['category']); ?></span>
                            <span class="badge <?php echo $status_badge; ?>"><?php echo htmlspecialchars($project['status']); ?></span>
                        </div>
                        <span onclick="event.stopPropagation(); event.preventDefault(); window.location.href='project-bookmark.php?id=<?php echo $project['id']; ?>&redirect=bookmarks'"
                           class="bookmark-icon-card bookmarked"
                           title="Hapus dari Bookmark">
                            <i class="fa-solid fa-bookmark"></i>
                        </span>
                    </div>

                    <div class="project-title"><?php echo htmlspecialchars($project['title']); ?></div>
                    <div class="project-desc"><?php echo htmlspecialchars($project['description']); ?></div>

                    <?php if (!empty($p_skills)): ?>
                    <div class="skill-tags-list">
                        <?php foreach (array_slice($p_skills, 0, 4) as $sk): ?>
                            <span class="skill-tag"><?php echo htmlspecialchars($sk); ?></span>
                        <?php endforeach; ?>
                        <?php if (count($p_skills) > 4): ?>
                            <span class="skill-tag">+<?php echo count($p_skills) - 4; ?></span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <div class="project-meta">
                        <span class="project-meta-item">
                            <i class="fa-solid fa-users"></i> <?php echo htmlspecialchars($project['slots']); ?> slot
                        </span>
                        <?php if (!empty($project['deadline'])): ?>
                        <span class="project-meta-item">
                            <i class="fa-regular fa-calendar"></i>
                            <?php echo date('d M Y', strtotime($project['deadline'])); ?>
                        </span>
                        <?php endif; ?>
                    </div>

                    <div class="project-card-footer">
                        <div class="owner-info"
                             onclick="event.stopPropagation(); event.preventDefault(); window.location.href='profile.php?id=<?php echo $project['owner_id']; ?>'">
                            <?php if (!empty($project['owner_foto']) && file_exists('uploads/' . $project['owner_foto'])): ?>
                                <img src="uploads/<?php echo htmlspecialchars($project['owner_foto']); ?>" alt="" class="owner-avatar">
                            <?php else: ?>
                                <div class="owner-avatar-placeholder"><?php echo $p_init; ?></div>
                            <?php endif; ?>
                            <span class="owner-name"><?php echo htmlspecialchars($project['owner_name']); ?></span>
                        </div>
                        <span class="link-arrow">Lihat <i class="fa-solid fa-arrow-right"></i></span>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
