<?php
require_once 'includes/functions.php';
require_login();

$project_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$user_id = $_SESSION['user_id'];
$redirect = sanitize($_GET['redirect'] ?? 'feed.php');

if ($project_id <= 0) {
    set_flash_message('error', 'Project tidak valid.');
    header("Location: feed.php");
    exit();
}

try {
    // Check if project exists
    $stmt = $pdo->prepare("SELECT id, title FROM projects WHERE id = ?");
    $stmt->execute([$project_id]);
    $project = $stmt->fetch();

    if (!$project) {
        set_flash_message('error', 'Project tidak ditemukan.');
        header("Location: feed.php");
        exit();
    }

    // Check if already bookmarked
    $bm_stmt = $pdo->prepare("SELECT id FROM project_bookmarks WHERE user_id = ? AND project_id = ?");
    $bm_stmt->execute([$user_id, $project_id]);
    $bookmark = $bm_stmt->fetch();

    if ($bookmark) {
        // Remove bookmark
        $del_stmt = $pdo->prepare("DELETE FROM project_bookmarks WHERE user_id = ? AND project_id = ?");
        $del_stmt->execute([$user_id, $project_id]);
        
        log_activity('Project Unbookmarked', "User {$user_id} removed project ID {$project_id} from bookmarks.");
        set_flash_message('info', 'Project dihapus dari daftar disimpan.');
    } else {
        // Add bookmark
        $ins_stmt = $pdo->prepare("INSERT INTO project_bookmarks (user_id, project_id) VALUES (?, ?)");
        $ins_stmt->execute([$user_id, $project_id]);
        
        log_activity('Project Bookmarked', "User {$user_id} added project ID {$project_id} to bookmarks.");
        set_flash_message('success', 'Project disimpan ke profil Anda.');
    }

} catch (PDOException $e) {
    set_flash_message('error', 'Gagal memproses penanda: ' . $e->getMessage());
}

// Redirect back to referrer safely
if ($redirect === 'detail') {
    header("Location: project-detail.php?id=" . $project_id);
} elseif ($redirect === 'profile') {
    header("Location: profile.php");
} elseif ($redirect === 'bookmarks') {
    header("Location: bookmarks.php");
} else {
    header("Location: feed.php");
}
exit();
?>
