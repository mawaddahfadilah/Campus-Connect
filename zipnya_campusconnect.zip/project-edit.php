<?php
require_once 'includes/functions.php';
require_login();

$project_id = isset($_GET['id']) ? intval($_GET['id']) : (isset($_POST['id']) ? intval($_POST['id']) : 0);
$user_id = $_SESSION['user_id'];
$error = '';

try {
    // Fetch project details
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$project_id]);
    $project = $stmt->fetch();

    if (!$project) {
        set_flash_message('error', 'Project tidak ditemukan.');
        header("Location: feed.php");
        exit();
    }

    // Check ownership
    if ($project['owner_id'] !== $user_id) {
        set_flash_message('error', 'Anda tidak memiliki hak untuk mengubah project ini.');
        header("Location: feed.php");
        exit();
    }

    // Fetch skills
    $skills_stmt = $pdo->prepare("SELECT skill_name FROM project_skills WHERE project_id = ?");
    $skills_stmt->execute([$project_id]);
    $current_skills = $skills_stmt->fetchAll(PDO::FETCH_COLUMN);
    $skills_string = implode(',', $current_skills);

} catch (PDOException $e) {
    set_flash_message('error', 'Terjadi kesalahan database: ' . $e->getMessage());
    header("Location: feed.php");
    exit();
}

// Handle POST request (Update or Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        // DELETE action
        try {
            $del_stmt = $pdo->prepare("DELETE FROM projects WHERE id = ?");
            $del_stmt->execute([$project_id]);

            log_activity('Project Deleted', "Project \"{$project['title']}\" (ID {$project_id}) deleted by owner.");
            
            set_flash_message('success', 'Project kolaborasi berhasil dihapus.');
            header("Location: profile.php");
            exit();
        } catch (PDOException $e) {
            $error = 'Gagal menghapus project: ' . $e->getMessage();
        }
    } else {
        // UPDATE action
        $title = sanitize($_POST['title'] ?? '');
        $category = sanitize($_POST['category'] ?? '');
        $description = sanitize($_POST['description'] ?? '');
        $slots = isset($_POST['slots']) ? intval($_POST['slots']) : 0;
        $deadline = sanitize($_POST['deadline'] ?? '');
        $status = sanitize($_POST['status'] ?? 'Open');
        $contact_link = sanitize($_POST['contact_link'] ?? '');
        $skills_input = sanitize($_POST['skills'] ?? '');

        $allowed_categories = ['PKM', 'P2MW', 'Lomba', 'Startup', 'Volunteer', 'Organisasi', 'Event Kampus', 'Lainnya'];
        $allowed_statuses = ['Open', 'Closed'];

        if (empty($title) || empty($category) || empty($description) || $slots <= 0 || empty($deadline)) {
            $error = 'Semua field wajib diisi (kecuali link kontak).';
        } elseif (!in_array($category, $allowed_categories)) {
            $error = 'Kategori tidak valid.';
        } elseif (!in_array($status, $allowed_statuses)) {
            $error = 'Status tidak valid.';
        } else {
            try {
                $pdo->beginTransaction();

                // Update project
                $up_stmt = $pdo->prepare("UPDATE projects SET title = ?, category = ?, description = ?, slots = ?, deadline = ?, status = ?, contact_link = ? WHERE id = ?");
                $up_stmt->execute([
                    $title,
                    $category,
                    $description,
                    $slots,
                    $deadline,
                    $status,
                    !empty($contact_link) ? $contact_link : null,
                    $project_id
                ]);

                // Update skills (delete old and insert new)
                $del_skills = $pdo->prepare("DELETE FROM project_skills WHERE project_id = ?");
                $del_skills->execute([$project_id]);

                if (!empty($skills_input)) {
                    $skills_array = array_unique(array_filter(array_map('trim', explode(',', $skills_input))));
                    $ins_skill = $pdo->prepare("INSERT INTO project_skills (project_id, skill_name) VALUES (?, ?)");
                    foreach ($skills_array as $skill) {
                        if (!empty($skill)) {
                            $ins_skill->execute([$project_id, $skill]);
                        }
                    }
                }

                $pdo->commit();

                log_activity('Project Updated', "Project \"$title\" (ID $project_id) updated by owner.");

                set_flash_message('success', 'Project kolaborasi berhasil diperbarui.');
                header("Location: project-detail.php?id=" . $project_id);
                exit();

            } catch (PDOException $e) {
                $pdo->rollBack();
                $error = 'Gagal memperbarui project: ' . $e->getMessage();
            }
        }
    }
}

require_once 'includes/header.php';
?>

<div class="app-container">
    <div class="feed-header animate-fade-in">
        <div class="feed-title-area">
            <h2>Ubah Project: <?php echo htmlspecialchars($project['title']); ?></h2>
            <p>Ubah detail postingan, kebutuhan anggota, atau kelola status kolaborasi</p>
        </div>
        <a href="project-detail.php?id=<?php echo $project['id']; ?>" class="btn btn-secondary"><i class="fa-solid fa-arrow-left"></i> Kembali ke Detail</a>
    </div>

    <?php if (!empty($error)): ?>
        <div class="flash-banner flash-error animate-fade-in">
            <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 30px; margin-top: 20px;" class="animate-fade-in">
        
        <!-- Form Update -->
        <div class="card">
            <form action="project-edit.php" method="POST" class="validate-form">
                <input type="hidden" name="id" value="<?php echo $project['id']; ?>">

                <div class="form-group">
                    <label for="title" class="form-label">Judul Project</label>
                    <input type="text" name="title" id="title" class="form-input" required value="<?php echo htmlspecialchars($project['title']); ?>">
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                    <div class="form-group">
                        <label for="category" class="form-label">Kategori Project</label>
                        <select name="category" id="category" class="form-input" required>
                            <option value="PKM" <?php echo ($project['category'] == 'PKM') ? 'selected' : ''; ?>>PKM</option>
                            <option value="P2MW" <?php echo ($project['category'] == 'P2MW') ? 'selected' : ''; ?>>P2MW</option>
                            <option value="Lomba" <?php echo ($project['category'] == 'Lomba') ? 'selected' : ''; ?>>Lomba</option>
                            <option value="Startup" <?php echo ($project['category'] == 'Startup') ? 'selected' : ''; ?>>Startup</option>
                            <option value="Volunteer" <?php echo ($project['category'] == 'Volunteer') ? 'selected' : ''; ?>>Volunteer</option>
                            <option value="Organisasi" <?php echo ($project['category'] == 'Organisasi') ? 'selected' : ''; ?>>Organisasi</option>
                            <option value="Event Kampus" <?php echo ($project['category'] == 'Event Kampus') ? 'selected' : ''; ?>>Event Kampus</option>
                            <option value="Lainnya" <?php echo ($project['category'] == 'Lainnya') ? 'selected' : ''; ?>>Lainnya</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="status" class="form-label">Status Project</label>
                        <select name="status" id="status" class="form-input" required>
                            <option value="Open" <?php echo ($project['status'] == 'Open') ? 'selected' : ''; ?>>Open (Buka Pendaftaran)</option>
                            <option value="Closed" <?php echo ($project['status'] == 'Closed') ? 'selected' : ''; ?>>Closed (Tutup Pendaftaran)</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="description" class="form-label">Deskripsi Lengkap Project</label>
                    <textarea name="description" id="description" class="form-input" rows="6" required style="resize: vertical; font-family: inherit;"><?php echo htmlspecialchars($project['description']); ?></textarea>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                    <div class="form-group">
                        <label for="slots" class="form-label">Jumlah Anggota yang Dicari (Slot)</label>
                        <input type="number" name="slots" id="slots" class="form-input" min="1" required value="<?php echo htmlspecialchars($project['slots']); ?>">
                    </div>

                    <div class="form-group">
                        <label for="deadline" class="form-label">Deadline Pendaftaran</label>
                        <input type="date" name="deadline" id="deadline" class="form-input" required value="<?php echo htmlspecialchars($project['deadline']); ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label for="contact_link" class="form-label">Tautan Komunikasi Utama</label>
                    <input type="url" name="contact_link" id="contact_link" class="form-input" placeholder="https://chat.whatsapp.com/... atau https://discord.gg/..." value="<?php echo htmlspecialchars($project['contact_link'] ?? ''); ?>">
                </div>

                <!-- Dynamic Tags Input for Project Skills -->
                <div class="form-group">
                    <label class="form-label">Keahlian yang Dibutuhkan</label>
                    <div class="tags-input-container">
                        <!-- Tags render here -->
                        <input type="text" id="skill_type_input" placeholder="Ketik keahlian lalu tekan Enter atau Koma">
                    </div>
                    <input type="hidden" name="skills" value="<?php echo htmlspecialchars($skills_string); ?>">
                    <small class="form-help">Tekan Enter atau ketik koma ( , ) untuk menambah tag.</small>
                    
                    <div style="margin-top: 14px;">
                        <div class="predefined-tags-list">
                            <button type="button" class="predefined-tag-btn" data-tag="UI/UX">UI/UX</button>
                            <button type="button" class="predefined-tag-btn" data-tag="Figma">Figma</button>
                            <button type="button" class="predefined-tag-btn" data-tag="HTML">HTML</button>
                            <button type="button" class="predefined-tag-btn" data-tag="CSS">CSS</button>
                            <button type="button" class="predefined-tag-btn" data-tag="JavaScript">JavaScript</button>
                            <button type="button" class="predefined-tag-btn" data-tag="PHP">PHP</button>
                            <button type="button" class="predefined-tag-btn" data-tag="MySQL">MySQL</button>
                            <button type="button" class="predefined-tag-btn" data-tag="Python">Python</button>
                        </div>
                    </div>
                </div>

                <div style="display: flex; gap: 16px; justify-content: flex-end; margin-top: 30px; border-top: 1px solid var(--card-border); padding-top: 20px;">
                    <a href="project-detail.php?id=<?php echo $project['id']; ?>" class="btn btn-secondary">Batal</a>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>

        <!-- Danger Zone Box -->
        <div style="display: flex; flex-direction: column; gap: 24px;">
            <div class="card" style="border-color: rgba(239, 68, 68, 0.3); background: rgba(239, 68, 68, 0.02);">
                <div class="profile-section-title" style="border-left-color: var(--danger); color: var(--danger); margin-bottom: 12px;">Danger Zone</div>
                <p style="font-size: 0.9rem; color: var(--text-secondary); margin-bottom: 20px;">
                    Menghapus project ini akan membatalkan seluruh pendaftaran pelamar yang masih pending dan membubarkan tim kolaborasi yang telah terbentuk secara permanen.
                </p>
                <form action="project-edit.php" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus project ini secara permanen? Tindakan ini tidak dapat dibatalkan.');">
                    <input type="hidden" name="id" value="<?php echo $project['id']; ?>">
                    <input type="hidden" name="action" value="delete">
                    <button type="submit" class="btn btn-danger" style="width: 100%;">
                        <i class="fa-regular fa-trash-can"></i> Hapus Project Permanen
                    </button>
                </form>
            </div>
        </div>

    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
