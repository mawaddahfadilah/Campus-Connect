<?php
require_once 'includes/functions.php';
require_login();

$user_id = $_SESSION['user_id'];

// Process mark all as read
if (isset($_POST['action']) && $_POST['action'] === 'read_all') {
    try {
        $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
        $stmt->execute([$user_id]);
        set_flash_message('success', 'Semua notifikasi ditandai telah dibaca.');
        header("Location: notifications.php");
        exit();
    } catch (PDOException $e) {
        $error = 'Gagal memperbarui notifikasi: ' . $e->getMessage();
    }
}

// Fetch user notifications
$notifications = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC");
    $stmt->execute([$user_id]);
    $notifications = $stmt->fetchAll();
} catch (PDOException $e) {
    set_flash_message('error', 'Gagal memuat notifikasi.');
}

require_once 'includes/header.php';
?>

<div class="app-container">
    <div class="feed-header animate-fade-in">
        <div class="feed-title-area">
            <h2>Pemberitahuan & Notifikasi</h2>
            <p>Pantau status pendaftaran kolaborasi dan aktivitas tim Anda di sini</p>
        </div>
        
        <?php if (get_unread_notifications_count($user_id) > 0): ?>
            <form action="notifications.php" method="POST">
                <input type="hidden" name="action" value="read_all">
                <button type="submit" class="btn btn-secondary btn-sm">
                    <i class="fa-solid fa-envelope-open"></i> Tandai Semua Dibaca
                </button>
            </form>
        <?php endif; ?>
    </div>

    <!-- Notification Stream -->
    <div class="animate-fade-in" style="margin-top: 20px; animation-delay: 0.1s;">
        <?php if (empty($notifications)): ?>
            <div class="empty-state card">
                <div class="empty-state-icon"><i class="fa-solid fa-bell-slash"></i></div>
                <div class="empty-state-title">Tidak ada notifikasi</div>
                <p>Semua info terbaru mengenai project dan rekrutmen Anda akan tampil di sini.</p>
            </div>
        <?php else: ?>
            <div style="display: flex; flex-direction: column;">
                <?php foreach ($notifications as $notif): 
                    $unread_class = ($notif['is_read'] == 0) ? 'notification-unread' : '';
                ?>
                    <div class="notification-item <?php echo $unread_class; ?>">
                        <div class="notification-content">
                            <div class="notification-text"><?php echo $notif['message']; ?></div>
                            <div class="notification-time">
                                <i class="fa-regular fa-clock"></i> <?php echo date('d M Y, H:i', strtotime($notif['created_at'])); ?>
                            </div>
                        </div>
                        <?php if ($notif['is_read'] == 0): ?>
                            <span style="width: 8px; height: 8px; background: var(--primary); border-radius: 50%; display: inline-block; margin-left: 16px; box-shadow: 0 0 8px var(--primary);"></span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php 
// Mark notifications as read upon loading this page
try {
    $read_stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
    $read_stmt->execute([$user_id]);
} catch (Exception $e) {}

require_once 'includes/footer.php'; 
?>
