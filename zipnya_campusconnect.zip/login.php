<?php
require_once 'includes/functions.php';

if (is_logged_in()) {
    header("Location: " . (is_admin() ? "admin-dashboard.php" : "feed.php"));
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = sanitize($_POST['email']    ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Email dan password wajib diisi.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['name']    = $user['name'];
                $_SESSION['email']   = $user['email'];
                $_SESSION['role']    = $user['role'];
                $_SESSION['foto']    = $user['foto'];

                log_activity('User Logged In', "User {$user['name']} ({$user['email']}) logged in.");
                set_flash_message('success', 'Selamat datang, ' . htmlspecialchars($user['name']) . '!');

                header("Location: " . ($user['role'] === 'admin' ? "admin-dashboard.php" : "feed.php"));
                exit();
            } else {
                $error = 'Email atau password salah.';
            }
        } catch (PDOException $e) {
            $error = 'Terjadi kesalahan sistem.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Masuk ke CampusConnect — platform kolaborasi mahasiswa.">
    <title>Masuk — CampusConnect</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css?v=2.3">
</head>
<body>

<div class="auth-page-wrapper">
    <div class="auth-container animate-fade-in">

        <!-- Logo -->
        <div class="auth-logo">
            <a href="index.php" class="logo" style="justify-content:center; font-size:1.5rem;">
                <span class="logo-campus">Campus</span><span class="logo-connect">Connect</span>
            </a>
        </div>

        <div class="auth-card">
            <h1 class="auth-title">Selamat Datang</h1>
            <p class="auth-subtitle">Masuk untuk mengelola project dan kolaborator Anda</p>

            <?php if (!empty($error)): ?>
                <div class="flash-banner flash-error">
                    <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form action="login.php" method="POST">
                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" name="email" id="email" class="form-input"
                           placeholder="nama@student.kampus.ac.id" required
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                </div>

                <div class="form-group">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                        <label for="password" class="form-label" style="margin-bottom:0;">Password</label>
                        <a href="forgot-password.php" class="auth-link" style="font-size:0.825rem;">Lupa Password?</a>
                    </div>
                    <input type="password" name="password" id="password" class="form-input"
                           placeholder="Masukkan password Anda" required>
                </div>

                <button type="submit" class="btn btn-primary" style="width:100%; margin-top:8px; padding:12px;">
                    Masuk
                </button>
            </form>
        </div>

        <div class="auth-footer">
            Belum punya akun? <a href="register.php" class="auth-link">Daftar sekarang</a>
        </div>
    </div>
</div>

</body>
</html>
