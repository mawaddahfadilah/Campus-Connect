<?php
require_once 'includes/functions.php';

// Redirect if already logged in
if (is_logged_in()) {
    header("Location: feed.php");
    exit();
}

$error = '';
$simulation_link = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');

    if (empty($email)) {
        $error = 'Email wajib diisi.';
    } elseif (!validate_email($email)) {
        $error = 'Format email tidak valid.';
    } else {
        try {
            // Check if email exists
            $stmt = $pdo->prepare("SELECT id, name FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                // Generate token
                $token = bin2hex(random_bytes(20));
                $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

                // Save token in DB
                $update_stmt = $pdo->prepare("UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?");
                $update_stmt->execute([$token, $expires, $user['id']]);

                // Create simulation link
                $simulation_link = "reset-password.php?token=" . $token;
                
                log_activity('Forgot Password Requested', "Password reset token generated for user {$user['name']} ($email).");
            } else {
                $error = 'Email tidak ditemukan di sistem kami.';
            }
        } catch (PDOException $e) {
            $error = 'Terjadi kesalahan: ' . $e->getMessage();
        }
    }
}

require_once 'includes/header.php';
?>

<div class="app-container">
    <div class="auth-container animate-fade-in">
        <div class="auth-header">
            <h2 class="auth-title">Lupa Password</h2>
            <p class="auth-subtitle">Masukkan email Anda untuk melakukan reset password</p>
        </div>

        <?php if (!empty($error)): ?>
            <div class="flash-banner flash-error">
                <i class="fa-solid fa-triangle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($simulation_link)): ?>
            <div class="simulation-banner animate-fade-in">
                <h4><i class="fa-solid fa-flask"></i> Simulasi Lingkungan Lokal</h4>
                <p style="font-size: 0.9rem; color: var(--text-secondary); margin-bottom: 10px;">
                    Karena berjalan di server lokal, email pemulihan tidak dikirim. Silakan klik tautan di bawah ini untuk mensimulasikan proses reset password:
                </p>
                <a href="<?php echo htmlspecialchars($simulation_link); ?>">
                    <i class="fa-solid fa-key"></i> Klik untuk Reset Password Anda
                </a>
            </div>
        <?php endif; ?>

        <div class="card">
            <form action="forgot-password.php" method="POST" class="validate-form">
                <div class="form-group">
                    <label for="email" class="form-label">Email Mahasiswa</label>
                    <input type="email" name="email" id="email" class="form-input" placeholder="Contoh: ahmed@student.ui.ac.id" required>
                    <small class="form-help">Link reset password simulasi akan muncul di atas setelah Anda menekan tombol di bawah.</small>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;">Kirim Link Reset</button>
            </form>
        </div>

        <div class="auth-footer">
            Kembali ke <a href="login.php" class="auth-link">Masuk</a>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
