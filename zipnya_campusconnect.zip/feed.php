<?php
require_once 'includes/functions.php';
require_login();

$search   = sanitize($_GET['search']   ?? '');
$category = sanitize($_GET['category'] ?? '');
$skill    = sanitize($_GET['skill']    ?? '');

$query  = "SELECT p.*, u.name as owner_name, u.foto as owner_foto
           FROM projects p JOIN users u ON p.owner_id = u.id WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (p.title LIKE :search OR p.description LIKE :search)";
    $params['search'] = '%' . $search . '%';
}
if (!empty($category)) {
    $query .= " AND p.category = :category";
    $params['category'] = $category;
}
if (!empty($skill)) {
    $query .= " AND p.id IN (SELECT project_id FROM project_skills WHERE skill_name LIKE :skill)";
    $params['skill'] = '%' . $skill . '%';
}
$query .= " ORDER BY CASE WHEN p.status = 'Open' THEN 1 ELSE 2 END, p.id DESC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $projects = $stmt->fetchAll();
} catch (PDOException $e) {
    set_flash_message('error', 'Gagal memuat feed: ' . $e->getMessage());
    $projects = [];
}

$categories = ['PKM', 'P2MW', 'Lomba', 'Startup', 'Volunteer', 'Organisasi', 'Event Kampus', 'Lainnya'];

$bookmarked_ids = [];
if (is_logged_in() && $_SESSION['role'] !== 'admin') {
    try {
        $bm_stmt = $pdo->prepare("SELECT project_id FROM project_bookmarks WHERE user_id = ?");
        $bm_stmt->execute([$_SESSION['user_id']]);
        $bookmarked_ids = $bm_stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {}
}

require_once 'includes/header.php';
?>

<div class="app-container">

    <!-- Page Header -->
    <div class="page-header animate-fade-in">
        <div class="page-header-text">
            <h1>Jelajahi Project Kolaborasi</h1>
            <p>Temukan project akademik dan non-akademik yang membutuhkan keahlian Anda</p>
        </div>
        <a href="project-create.php" class="btn btn-primary" style="flex-shrink:0;">
            <i class="fa-solid fa-plus"></i> Buat Project Baru
        </a>
    </div>

    <!-- Filter Bar -->
    <form action="feed.php" method="GET">
        <div class="filter-bar animate-fade-in">
            <input type="text" name="search" class="form-input search-input"
                   placeholder="&#xf002;  Cari judul atau deskripsi..."
                   value="<?php echo htmlspecialchars($search); ?>">

            <select name="category" class="form-input filter-select">
                <option value="">Semua Kategori</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo $cat; ?>" <?php echo ($category === $cat) ? 'selected' : ''; ?>>
                        <?php echo $cat; ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <input type="text" name="skill" class="form-input filter-select"
                   placeholder="Filter skill (mis: Figma)..."
                   value="<?php echo htmlspecialchars($skill); ?>">

            <button type="submit" class="btn btn-primary btn-sm">
                <i class="fa-solid fa-magnifying-glass"></i> Cari
            </button>
            <?php if (!empty($search) || !empty($category) || !empty($skill)): ?>
                <a href="feed.php" class="btn btn-neutral btn-sm" title="Reset">
                    <i class="fa-solid fa-xmark"></i>
                </a>
            <?php endif; ?>
        </div>
    </form>

    <!-- Result Count -->
    <?php if (!empty($search) || !empty($category) || !empty($skill)): ?>
        <p class="feed-result-info animate-fade-in">
            <i class="fa-solid fa-filter" style="color:var(--color-primary);"></i>
            Menampilkan <strong><?php echo count($projects); ?></strong> project
            <?php if (!empty($search)): ?> untuk "<em><?php echo htmlspecialchars($search); ?></em>"<?php endif; ?>
            <?php if (!empty($category)): ?> · Kategori: <strong><?php echo htmlspecialchars($category); ?></strong><?php endif; ?>
            <?php if (!empty($skill)): ?> · Skill: <strong><?php echo htmlspecialchars($skill); ?></strong><?php endif; ?>
        </p>
    <?php endif; ?>

    <!-- Project Grid -->
    <div class="animate-fade-in" style="animation-delay:0.08s;">
        <?php if (empty($projects)): ?>
            <div class="empty-state card">
                <div class="empty-state-icon"><i class="fa-solid fa-folder-open"></i></div>
                <div class="empty-state-title">Tidak ada project ditemukan</div>
                <p class="empty-state-desc">Tidak ada project yang cocok dengan pencarian atau filter Anda.</p>
                <a href="feed.php" class="btn btn-secondary">Reset Pencarian</a>
            </div>
        <?php else: ?>
            <div class="project-grid">
                <?php foreach ($projects as $project):
                    $p_skills = [];
                    try {
                        $ps_stmt = $pdo->prepare("SELECT skill_name FROM project_skills WHERE project_id = ?");
                        $ps_stmt->execute([$project['id']]);
                        $p_skills = $ps_stmt->fetchAll(PDO::FETCH_COLUMN);
                    } catch (Exception $e) {}

                    $cat_lower = strtolower($project['category']);
                    $badge_cls = 'badge-lainnya';
                    $cat_map   = ['pkm'=>'pkm','p2mw'=>'p2mw','lomba'=>'lomba','startup'=>'startup','volunteer'=>'volunteer','organisasi'=>'organisasi','event kampus'=>'event'];
                    if (isset($cat_map[$cat_lower])) $badge_cls = 'badge-' . $cat_map[$cat_lower];

                    $status_badge = ($project['status'] === 'Open') ? 'badge-open' : 'badge-closed';
                    $is_bookmarked = in_array($project['id'], $bookmarked_ids);

                    $p_parts = explode(' ', $project['owner_name']);
                    $p_init  = strtoupper(substr($p_parts[0],0,1).(isset($p_parts[1])?substr($p_parts[1],0,1):''));
                ?>
                <a href="project-detail.php?id=<?php echo $project['id']; ?>" class="project-card animate-fade-in">
                    <div class="project-card-top">
                        <div class="project-card-badges">
                            <span class="badge <?php echo $badge_cls; ?>"><?php echo htmlspecialchars($project['category']); ?></span>
                            <span class="badge <?php echo $status_badge; ?>"><?php echo htmlspecialchars($project['status']); ?></span>
                        </div>
                        <?php if ($_SESSION['role'] !== 'admin'): ?>
                            <span onclick="event.stopPropagation(); window.location.href='project-bookmark.php?id=<?php echo $project['id']; ?>&redirect=feed'"
                               class="bookmark-icon-card <?php echo $is_bookmarked ? 'bookmarked' : ''; ?>"
                               title="<?php echo $is_bookmarked ? 'Hapus Penanda' : 'Simpan'; ?>">
                                <i class="<?php echo $is_bookmarked ? 'fa-solid' : 'fa-regular'; ?> fa-bookmark"></i>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="project-title"><?php echo htmlspecialchars($project['title']); ?></div>
                    <div class="project-desc"><?php echo htmlspecialchars($project['description']); ?></div>

                    <?php if (!empty($p_skills)): ?>
                    <div class="skill-tags-list">
                        <?php foreach (array_slice($p_skills, 0, 4) as $sk): ?>
                            <span class="skill-tag"><?php echo htmlspecialchars($sk); ?></span>
                        <?php endforeach; ?>
                        <?php if (count($p_skills) > 4): ?>
                            <span class="skill-tag">+<?php echo count($p_skills) - 4; ?></span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <div class="project-meta">
                        <span class="project-meta-item">
                            <i class="fa-solid fa-users"></i> <?php echo htmlspecialchars($project['slots']); ?> slot
                        </span>
                        <?php if (!empty($project['deadline'])): ?>
                        <span class="project-meta-item">
                            <i class="fa-regular fa-calendar"></i>
                            <?php echo date('d M Y', strtotime($project['deadline'])); ?>
                        </span>
                        <?php endif; ?>
                    </div>

                    <div class="project-card-footer">
                        <div class="owner-info"
                             onclick="event.stopPropagation(); window.location.href='profile.php?id=<?php echo $project['owner_id']; ?>'">
                            <?php if (!empty($project['owner_foto']) && file_exists('uploads/' . $project['owner_foto'])): ?>
                                <img src="uploads/<?php echo htmlspecialchars($project['owner_foto']); ?>" alt="" class="owner-avatar">
                            <?php else: ?>
                                <div class="owner-avatar-placeholder"><?php echo $p_init; ?></div>
                            <?php endif; ?>
                            <span class="owner-name"><?php echo htmlspecialchars($project['owner_name']); ?></span>
                        </div>
                        <span class="link-arrow">Lihat <i class="fa-solid fa-arrow-right"></i></span>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

</div>

<style>
.feed-result-info {
    font-size: 0.875rem;
    color: var(--color-text-secondary);
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 8px;
}
</style>

<?php require_once 'includes/footer.php'; ?>
